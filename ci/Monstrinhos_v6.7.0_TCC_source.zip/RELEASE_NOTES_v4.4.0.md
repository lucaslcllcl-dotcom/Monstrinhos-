# Monstrinhos v4.4.0
- Nova identidade visual procedural para os 32 monstrinhos: quatro silhuetas, orelhas/chifres, marcas, expressões e aro raro.
- Home, Álbum e revelação de ovo agora usam a identidade estável do ID do monstrinho.
- Modo de cores acessíveis preservado com paleta de alto contraste; silhuetas ajudam a diferenciar personagens sem depender só de cor.
- Sem SDK de anúncios ou compras reais. Package ID e save `monstrinhos_save_v1` preservados.
