Monstrinhos rebuild v6.5.0

# Monstrinhos rebuild v1.2.0
Base Android reconstruída e evolutiva. Identidade congelada: `com.caeless.monstrinhos`; save: `monstrinhos_save_v1`.

v1.2.0 adiciona o modo jogável **Desafio Rápido**, pontuação/recorde persistentes, recompensa em moedas e conquista por completar 10 acertos. Monetização real permanece ausente.

## v1.3.0-rebuild
- Álbum agora exibe os 32 monstrinhos em duas páginas (1–16 e 17–32).
- Favorito pode ser escolhido em toda a coleção, não apenas entre os 12 primeiros.
- Estrela visual identifica o monstrinho favorito no álbum.
- Mantidos package ID e esquema de save; nenhuma monetização real adicionada.


## v1.5.0-rebuild
- Incubação revisada para desbloquear apenas monstrinhos ainda ausentes, sem desperdiçar ovos em duplicatas.
- Coleção completa agora é detectada e preserva ovos em vez de consumi-los.
- Conquista de álbum completo adicionada (bit 8192), mantendo save v1 aditivo.
- hatch_pity persistido para futura evolução do sistema de raridade/incubação.


## Evolução v1.5.0
- Raridade inicial: monstrinhos 25–32 são raros.
- Sistema de garantia (pity): após 5 incubações sem raro, o próximo raro ainda bloqueado é priorizado.
- Contador persistente `rare_monsters` e conquista ao obter 4 raros.
- Álbum mostra raros obtidos e ovos restantes para a garantia.
- Ovos não são consumidos se a coleção já estiver completa.


## v1.8.0-rebuild
- Chefes agora concedem fichas conforme as estrelas obtidas.
- Novo Baú de Chefe progressivo: troca fichas por moedas + ovo, com custo crescente.
- Progresso persistente `boss_tokens` e `boss_chest_level`; conquista ao abrir 3 baús.
- Monetização real continua desativada.


## v1.8.0-rebuild
- Sistema de amizade persistente ligado às reações desbloqueadas.
- Botão REAÇÃO no hub de missões permite interação ativa com o monstrinho favorito.
- A cada 5 reações, amizade sobe (até nível 6) e concede pequeno bônus de moedas.
- Nova conquista após 20 interações de reação.
- Novas chaves aditivas de save: `reaction_uses`, `friendship_level`.
- Anúncios e compras reais continuam ausentes/desativados.


## v1.8.0
- Casinha ganhou decoração persistente com 4 temas: Clássica, Floresta, Estrelas e Doce.
- Temas podem ser comprados apenas com moedas internas; sem compra real.
- Novas chaves aditivas de save: `house_decor`, `house_decor_owned`.
- Conquista adicional ao desbloquear todos os temas da casinha.


## v1.9.0-rebuild
- Campanha ampliada de 12 para 30 fases, divididas em 3 mundos de 10 fases.
- Chefes agora aparecem nas fases 5/10/15/20/25/30 e usam o mesmo sistema persistente de estrelas, fichas e recompensas.
- Navegação de mundos adicionada sem alterar o esquema `level_stars`, preservando saves anteriores.
- Estatísticas aditivas `session_wins` e `session_perfect`; conquista adicional após 10 vitórias perfeitas.
- Package ID e `monstrinhos_save_v1` preservados; monetização real continua ausente.


## v2.0.0-rebuild — robustez e acessibilidade
- Save defensivo com `save_schema=1` e sanitização de valores carregados.
- Preferência persistente de texto maior (`large_text`).
- Preferência persistente de movimento reduzido (`reduced_motion`), preparada para animações futuras.
- Identidade congelada preservada: package `com.caeless.monstrinhos` e save `monstrinhos_save_v1`.
- Monetização real continua desativada; sem SDK de anúncios ou Billing.


## v2.2.0-rebuild
- Preserva a sessão visual durante recriação da Activity/rotação: tela atual, fase, toques, erros, desafio, páginas e posição do alvo.
- Persiste o progresso no onPause para reduzir risco de perda ao app ir para segundo plano.
- Restauração defensiva limita índices e coordenadas a faixas válidas.
- Package `com.caeless.monstrinhos` e save `monstrinhos_save_v1` preservados.
- Monetização real continua ausente.


## v2.2.0
- Acessibilidade reforçada: View focalizável, descrição global, performClick e anúncios TalkBack para feedback de ações.
- Mantidos package/save e monetização real desativada.


## v2.4.0-rebuild
- Save schema 2 with backward-compatible migration/sanitization.
- Persistent optional gameplay hints toggle.
- Persistent high-contrast accessibility preference, prepared for renderer adoption.
- Monetization remains disabled; no AdMob/Billing SDK.


## v2.4.0
- Preferencias persistentes para modo amigavel a daltonismo e anuncios de acessibilidade.
- Mantem save `monstrinhos_save_v1` e package `com.caeless.monstrinhos`.
- Monetizacao real continua desativada.

## v5.8.0
- Corrigida sintaxe do ciclo diário da Casinha e adicionada validação `javac` com stubs Android para o núcleo de estado.
- Necessidades da Casinha passam a decair gradualmente entre dias e persistem via `needs_day` (schema 6).
- Evolução da Casinha requer 60% de bem-estar, conectando cuidado à progressão.


## Estado da base para compilação real
- Package: `com.caeless.monstrinhos`
- compileSdk / targetSdk: 36
- versão atual: 6.3.0 / 6300
- workflow CI incluído em `.github/workflows/android-debug-build.yml`
- monetização real continua desativada nesta etapa

### Bloqueio restante
Para gerar APK localmente ainda é necessário um ambiente com Android SDK, Gradle e ferramentas de assinatura/alinhamento (`apksigner`, `zipalign`).
