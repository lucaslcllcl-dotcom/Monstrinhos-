# Monstrinhos v5.6.0

- Casinha evolutiva ganha ações funcionais **Alimentar** e **Brincar**, além de Carinho.
- Alimentar custa 3 moedas do jogo e concede +2 de cuidado, limitado a 3 vezes por dia.
- Brincar concede +2 de cuidado, limitado a 3 vezes por dia; completar as 3 brincadeiras do dia rende 3 moedas.
- Contadores diários são persistidos e reiniciam junto com o dia de cuidado.
- Save migra aditivamente para schema 5, preservando `monstrinhos_save_v1`.
- Monetização real continua desativada.
