package com.caeless.monstrinhos;

import android.content.Context;
import android.content.SharedPreferences;

final class GameState {
    private static final String PREFS = "monstrinhos_save_v1"; // frozen for forward compatibility
    int coins=0, stars=0, level=1, eggs=0, incubatorType=0, houseLevel=1, streak=0, bestStreak=0, soundOn=1, vibrationOn=1, dailyClaimDay=0, missionsDone=0, missionRewardTier=0, totalHatched=0, bossWins=0, reactionsUnlocked=1, favoriteMonster=0, xp=0, playerLevel=1, bestScore=0, totalPlays=0, perfectBosses=0, houseVisits=0, carePoints=0, dailyStreak=0, bestDailyStreak=0, lastClaimDay=0, challengeWins=0, challengeBest=0, hatchPity=0, rareMonsters=0, bossTokens=0, bossChestLevel=0, reactionUses=0, friendshipLevel=1, houseDecor=0, houseDecorOwned=1, sessionWins=0, sessionPerfect=0, saveSchema=7, reducedMotion=0, largeText=0, hintsOn=1, highContrast=0, colorBlindMode=0, accessibilityAnnouncements=1, levelAttempts=0, levelFailures=0, bossFailures=0, lastHatchedMonster=-1, tutorialSeen=0, careDay=0, careToday=0, feedToday=0, playToday=0, mood=70, hunger=70, fun=70, needsDay=0;
    long ownedMask=1L, achievementMask=0L, incubatorReadyAt=0L;
    private String levelStars="";

    static GameState load(Context c){
        SharedPreferences p=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        GameState s=new GameState();
        s.coins=p.getInt("coins",0); s.stars=p.getInt("stars",0); s.level=p.getInt("level",1);
        s.eggs=p.getInt("eggs",0); s.incubatorType=p.getInt("incubator_type",0); s.incubatorReadyAt=p.getLong("incubator_ready_at",0L); s.houseLevel=p.getInt("house_level",1);
        s.ownedMask=p.getLong("owned_mask",1L); s.achievementMask=p.getLong("achievement_mask",0L);
        s.levelStars=p.getString("level_stars",""); s.dailyClaimDay=p.getInt("daily_claim_day",0); s.missionsDone=p.getInt("missions_done",0); s.streak=p.getInt("streak",0); s.bestStreak=p.getInt("best_streak",0); s.soundOn=p.getInt("sound_on",1); s.vibrationOn=p.getInt("vibration_on",1); s.missionRewardTier=p.getInt("mission_reward_tier",0); s.totalHatched=p.getInt("total_hatched",0); s.bossWins=p.getInt("boss_wins",0); s.reactionsUnlocked=p.getInt("reactions_unlocked",1); s.favoriteMonster=p.getInt("favorite_monster",0); s.xp=p.getInt("xp",0); s.playerLevel=p.getInt("player_level",1); s.bestScore=p.getInt("best_score",0); s.totalPlays=p.getInt("total_plays",0); s.perfectBosses=p.getInt("perfect_bosses",0); s.houseVisits=p.getInt("house_visits",0); s.carePoints=p.getInt("care_points",0); s.dailyStreak=p.getInt("daily_streak",0); s.bestDailyStreak=p.getInt("best_daily_streak",0); s.lastClaimDay=p.getInt("last_claim_day",0); s.challengeWins=p.getInt("challenge_wins",0); s.challengeBest=p.getInt("challenge_best",0); s.hatchPity=p.getInt("hatch_pity",0); s.rareMonsters=p.getInt("rare_monsters",0); s.bossTokens=p.getInt("boss_tokens",0); s.bossChestLevel=p.getInt("boss_chest_level",0); s.reactionUses=p.getInt("reaction_uses",0); s.friendshipLevel=p.getInt("friendship_level",1); s.houseDecor=p.getInt("house_decor",0); s.houseDecorOwned=p.getInt("house_decor_owned",1); s.sessionWins=p.getInt("session_wins",0); s.sessionPerfect=p.getInt("session_perfect",0); s.saveSchema=p.getInt("save_schema",1); s.reducedMotion=p.getInt("reduced_motion",0); s.largeText=p.getInt("large_text",0); s.hintsOn=p.getInt("hints_on",1); s.highContrast=p.getInt("high_contrast",0); s.colorBlindMode=p.getInt("color_blind_mode",0); s.accessibilityAnnouncements=p.getInt("accessibility_announcements",1); s.levelAttempts=p.getInt("level_attempts",0); s.levelFailures=p.getInt("level_failures",0); s.bossFailures=p.getInt("boss_failures",0); s.lastHatchedMonster=p.getInt("last_hatched_monster",-1); s.tutorialSeen=p.getInt("tutorial_seen",0); s.careDay=p.getInt("care_day",0); s.careToday=p.getInt("care_today",0); s.feedToday=p.getInt("feed_today",0); s.playToday=p.getInt("play_today",0); s.mood=p.getInt("mood",70); s.hunger=p.getInt("hunger",70); s.fun=p.getInt("fun",70); s.needsDay=p.getInt("needs_day",0); s.sanitize(); s.validateReleaseState();
        return s;
    }
    void save(Context c){
        refreshMetaAchievement();
        c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit()
          .putInt("coins",coins).putInt("stars",stars).putInt("level",level).putInt("eggs",eggs).putInt("incubator_type",incubatorType).putLong("incubator_ready_at",incubatorReadyAt)
          .putInt("house_level",houseLevel).putLong("owned_mask",ownedMask).putLong("achievement_mask",achievementMask)
          .putString("level_stars",levelStars).putInt("daily_claim_day",dailyClaimDay).putInt("missions_done",missionsDone).putInt("streak",streak).putInt("best_streak",bestStreak).putInt("sound_on",soundOn).putInt("vibration_on",vibrationOn).putInt("mission_reward_tier",missionRewardTier).putInt("total_hatched",totalHatched).putInt("boss_wins",bossWins).putInt("reactions_unlocked",reactionsUnlocked).putInt("favorite_monster",favoriteMonster).putInt("xp",xp).putInt("player_level",playerLevel).putInt("best_score",bestScore).putInt("total_plays",totalPlays).putInt("perfect_bosses",perfectBosses).putInt("house_visits",houseVisits).putInt("care_points",carePoints).putInt("daily_streak",dailyStreak).putInt("best_daily_streak",bestDailyStreak).putInt("last_claim_day",lastClaimDay).putInt("challenge_wins",challengeWins).putInt("challenge_best",challengeBest).putInt("hatch_pity",hatchPity).putInt("rare_monsters",rareMonsters).putInt("boss_tokens",bossTokens).putInt("boss_chest_level",bossChestLevel).putInt("reaction_uses",reactionUses).putInt("friendship_level",friendshipLevel).putInt("house_decor",houseDecor).putInt("house_decor_owned",houseDecorOwned).putInt("session_wins",sessionWins).putInt("session_perfect",sessionPerfect).putInt("save_schema",saveSchema).putInt("reduced_motion",reducedMotion).putInt("large_text",largeText).putInt("hints_on",hintsOn).putInt("high_contrast",highContrast).putInt("color_blind_mode",colorBlindMode).putInt("accessibility_announcements",accessibilityAnnouncements).putInt("level_attempts",levelAttempts).putInt("level_failures",levelFailures).putInt("boss_failures",bossFailures).putInt("last_hatched_monster",lastHatchedMonster).putInt("tutorial_seen",tutorialSeen).putInt("care_day",careDay).putInt("care_today",careToday).putInt("feed_today",feedToday).putInt("play_today",playToday).putInt("mood",mood).putInt("hunger",hunger).putInt("fun",fun).putInt("needs_day",needsDay).apply();
    }

    private void sanitize(){
        coins=Math.max(0,coins); stars=Math.max(0,stars); level=Math.max(1,Math.min(31,level)); eggs=Math.max(0,eggs);
        houseLevel=Math.max(1,Math.min(5,houseLevel)); playerLevel=Math.max(1,playerLevel); friendshipLevel=Math.max(1,Math.min(6,friendshipLevel));
        favoriteMonster=Math.max(0,Math.min(31,favoriteMonster)); houseDecor=Math.max(0,Math.min(3,houseDecor));
        ownedMask |= 1L; houseDecorOwned |= 1; reactionsUnlocked=Math.max(1,Math.min(6,reactionsUnlocked));
        saveSchema=Math.max(7,saveSchema); incubatorType=Math.max(0,Math.min(3,incubatorType)); if(incubatorReadyAt<0)incubatorReadyAt=0L; reducedMotion=reducedMotion==0?0:1; largeText=largeText==0?0:1; hintsOn=hintsOn==0?0:1; highContrast=highContrast==0?0:1; colorBlindMode=colorBlindMode==0?0:1; accessibilityAnnouncements=accessibilityAnnouncements==0?0:1; levelAttempts=Math.max(0,levelAttempts); levelFailures=Math.max(0,levelFailures); bossFailures=Math.max(0,bossFailures); lastHatchedMonster=Math.max(-1,Math.min(MonsterCatalog.count()-1,lastHatchedMonster)); tutorialSeen=tutorialSeen==0?0:1; careDay=Math.max(0,careDay); careToday=Math.max(0,Math.min(5,careToday)); feedToday=Math.max(0,Math.min(3,feedToday)); playToday=Math.max(0,Math.min(3,playToday)); mood=Math.max(0,Math.min(100,mood)); hunger=Math.max(0,Math.min(100,hunger)); fun=Math.max(0,Math.min(100,fun)); needsDay=Math.max(0,needsDay);
    }

    void markTutorialSeen(Context c){ tutorialSeen=1; save(c); }
    int playTargetHits(int stage){
        int base=isBoss(stage)?BossCatalog.target(stage):5;
        // Gentle anti-frustration assist: repeated misses make the next attempt slightly shorter,
        // without changing stars, rewards, unlocks or collection progress.
        int assist=(levelFailures>=3 || bossFailures>=2)?1:0;
        return Math.max(isBoss(stage)?6:4,base-assist);
    }
    boolean assistModeActive(){ return levelFailures>=3 || bossFailures>=2; }
    float hitRadiusPx(int width,int height){
        float base=Math.max(72f,Math.min(width,height)*0.115f);
        if(largeText==1) base*=1.08f;
        if(levelFailures>=3 && completionRate()<70) base*=1.10f;
        return Math.min(base,Math.min(width,height)*0.19f);
    }
    void toggleReducedMotion(Context c){reducedMotion=reducedMotion==1?0:1;save(c);}
    void toggleLargeText(Context c){largeText=largeText==1?0:1;save(c);}
    void toggleHints(Context c){hintsOn=hintsOn==1?0:1;save(c);}
    void toggleHighContrast(Context c){highContrast=highContrast==1?0:1;save(c);}
    void toggleColorBlindMode(Context c){colorBlindMode=colorBlindMode==1?0:1;save(c);}
    void toggleAccessibilityAnnouncements(Context c){accessibilityAnnouncements=accessibilityAnnouncements==1?0:1;save(c);}
    int starsFor(int n){ String[] a=levelStars.split(",",-1); if(n<1||n>a.length)return 0; try{return Integer.parseInt(a[n-1]);}catch(Exception e){return 0;} }
    private void setStarsFor(int n,int v){ String[] old=levelStars.isEmpty()?new String[0]:levelStars.split(",",-1); int size=Math.max(n,old.length); StringBuilder b=new StringBuilder(); for(int i=1;i<=size;i++){int x=i<=old.length?parse(old[i-1]):0;if(i==n)x=Math.max(x,v);if(i>1)b.append(',');b.append(x);}levelStars=b.toString(); }
    private int parse(String x){try{return Integer.parseInt(x);}catch(Exception e){return 0;}}
    boolean isBoss(int n){return n%5==0;}
    void beginLevel(Context c){ levelAttempts++; save(c); }
    void failLevel(Context c,int playedLevel){ levelFailures++; if(isBoss(playedLevel)) bossFailures++; streak=0; save(c); }
    int completionRate(){ return levelAttempts<=0?100:Math.max(0,Math.min(100,((levelAttempts-levelFailures)*100)/levelAttempts)); }
    void finishLevel(Context c,int playedLevel,int earnedStars){
        int balancedReward=rewardForLevel(playedLevel,earnedStars); coins+=balancedReward;
        earnedStars=Math.max(1,Math.min(3,earnedStars)); totalPlays++; sessionWins++; if(earnedStars==3) sessionPerfect++; if(isBoss(playedLevel)&&earnedStars==3) perfectBosses++; int before=starsFor(playedLevel); setStarsFor(playedLevel,earnedStars); stars+=Math.max(0,earnedStars-before);
        coins+=10+earnedStars*5+(isBoss(playedLevel)?20:0); if(isBoss(playedLevel)){bossWins++; bossTokens += earnedStars; reactionsUnlocked=Math.min(6,1+bossWins); if(bossWins>=3)achievementMask|=128L;} streak++; bestStreak=Math.max(bestStreak,streak); if(streak%3==0) coins+=10; if(playedLevel>=level) level=playedLevel+1;
        int score=earnedStars*100+(isBoss(playedLevel)?250:0)+Math.max(0,100-missesPenalty(earnedStars)); bestScore=Math.max(bestScore,score); addXp(earnedStars*20+(isBoss(playedLevel)?40:0)); if(level%3==0) eggs++; if(earnedStars==3) missionsDone++; if(bestStreak>=5) achievementMask|=16L; if(stars>=10) achievementMask|=1L; if(level>=5) achievementMask|=2L; if(Long.bitCount(ownedMask)>=5)achievementMask|=4L; if(houseLevel>=3)achievementMask|=8L; if(totalPlays>=20)achievementMask|=256L; if(perfectBosses>=3)achievementMask|=512L; if(sessionPerfect>=10)achievementMask|=262144L; save(c);
    }

    private int missesPenalty(int earnedStars){ return (3-earnedStars)*25; }
    private void addXp(int amount){ xp+=Math.max(0,amount); while(xp>=xpNeeded()){ xp-=xpNeeded(); playerLevel++; coins+=15; } }
    int xpNeeded(){ return 100+(playerLevel-1)*25; }
    boolean claimDaily(Context c){ int day=(int)(System.currentTimeMillis()/86400000L); if(dailyClaimDay==day)return false; if(lastClaimDay==day-1) dailyStreak++; else dailyStreak=1; bestDailyStreak=Math.max(bestDailyStreak,dailyStreak); lastClaimDay=day; dailyClaimDay=day; int bonus=Math.min(30,(dailyStreak-1)*5); coins+=20+bonus; if(dailyStreak%3==0)eggs++; if(dailyStreak>=7)achievementMask|=2048L; save(c); return true; }
    int currentDay(){ return (int)(System.currentTimeMillis()/86400000L); }
    boolean dailyAvailable(){ return dailyClaimDay!=currentDay(); }
    int nextDailyReward(){ int next=(lastClaimDay==currentDay()-1)?dailyStreak+1:1; return 20+Math.min(30,Math.max(0,next-1)*5); }
    int dailyReward(){ return 20+Math.min(30,Math.max(0,dailyStreak)*5); }
    String reactionForProgress(){ String[] r={"Que legal!","Uhuu!","Você conseguiu!","Incrível!","Super!","Amizade máxima!"}; return r[Math.max(0,Math.min(r.length-1,reactionsUnlocked-1))]; }
    String useReaction(Context c){
        refreshCareDay(); reactionUses++;
        // Reactions now reflect the favorite monster's current needs instead of being a generic text loop.
        String msg=companionReaction();
        mood=Math.min(100,mood+2);
        if(reactionUses%5==0 && friendshipLevel<6){ friendshipLevel++; coins+=5; msg += " Amizade subiu para "+friendshipLevel+"!"; }
        if(reactionUses>=20)achievementMask|=65536L;
        save(c); return msg;
    }
    String companionReaction(){
        String name=MonsterCatalog.name(favoriteMonster);
        if(hunger<=35) return name+" diz: nham... vamos comer?";
        if(fun<=35) return name+" quer brincar com você!";
        if(mood<=35) return name+" pediu um carinho.";
        String[] happy={"está pulando de alegria!","mandou um coração para você!","quer explorar uma fase!","está dançando na casinha!","deu uma risadinha feliz!","quer abrir um ovo com você!"};
        int idx=Math.floorMod(favoriteMonster+reactionUses+friendshipLevel,happy.length);
        return name+" "+happy[idx];
    }
    int friendshipNext(){ return friendshipLevel>=6?0:Math.max(0,5-(reactionUses%5)); }
    int friendshipGoal(){ return friendshipLevel>=6?0:5-(reactionUses%5); }
    boolean setFavorite(Context c,int idx){ if(idx<0||idx>31||(ownedMask&(1L<<idx))==0)return false; favoriteMonster=idx; save(c); return true; }
    boolean hatch(Context c){ if(eggs<=0||collectionComplete()) return false; eggs--; return revealHatch(c); }
    private boolean revealHatch(Context c){ return revealHatch(c,0); }
    private boolean revealHatch(Context c,int preferredType){ totalHatched++; hatchPity++; if(totalHatched>=5)achievementMask|=64L; int idx=nextLockedMonster(preferredType); if(idx>=0){ lastHatchedMonster=idx; ownedMask|=(1L<<idx); if(isRareMonster(idx)){ rareMonsters++; hatchPity=0; } if(hatchPity>=5) hatchPity=0; } if(Long.bitCount(ownedMask)>=5)achievementMask|=4L; if(rareMonsters>=4)achievementMask|=16384L; if(Long.bitCount(ownedMask)>=32)achievementMask|=8192L; save(c); return idx>=0; }
    boolean incubatorBusy(){ return incubatorReadyAt>0L; }
    boolean incubatorReady(){ return incubatorBusy() && System.currentTimeMillis()>=incubatorReadyAt; }
    long incubatorRemainingSeconds(){ return incubatorBusy()?Math.max(0L,(incubatorReadyAt-System.currentTimeMillis()+999L)/1000L):0L; }
    String incubatorEggName(){ String[] n={"Nenhum","Ovo Azul","Ovo Solar","Ovo Folha"}; return n[Math.max(0,Math.min(3,incubatorType))]; }
    boolean startIncubation(Context c,int type){ if(incubatorBusy()||eggs<=0||collectionComplete())return false; type=Math.max(1,Math.min(3,type)); eggs--; incubatorType=type; long[] seconds={0,120,240,360}; incubatorReadyAt=System.currentTimeMillis()+seconds[type]*1000L; save(c); return true; }
    int incubatorSpeedCost(){ return incubatorType==1?10:incubatorType==2?15:20; }
    String incubatorAffinity(){ String[] a={"","amigos da água","amigos solares","amigos da floresta"}; return a[Math.max(0,Math.min(3,incubatorType))]; }
    boolean speedIncubation(Context c){ int cost=incubatorSpeedCost(); if(!incubatorBusy()||incubatorReady()||coins<cost)return false; coins-=cost; incubatorReadyAt=System.currentTimeMillis(); save(c); return true; }
    boolean claimIncubation(Context c){ if(!incubatorReady()||collectionComplete())return false; int hatchedType=incubatorType; incubatorReadyAt=0L; incubatorType=0; boolean ok=revealHatch(c,hatchedType); save(c); return ok; }
    String incubatorClock(){ long x=incubatorRemainingSeconds(); return String.format(java.util.Locale.US,"%02d:%02d",x/60,x%60); }
    private int nextLockedMonster(){ return nextLockedMonster(0); }
    private int nextLockedMonster(int preferredType){ if(Long.bitCount(ownedMask)>=32)return -1; if(hatchPity>=5){ for(int i=0;i<32;i++)if(isRareMonster(i)&&(ownedMask&(1L<<i))==0)return i; } int start=(totalHatched*7+hatchPity*3)%32;
        // Nursery affinity: each egg color favors one third of the common collection.
        if(preferredType>=1 && preferredType<=3){
            int lo=(preferredType-1)*8, hi=preferredType==3?24:lo+8;
            for(int n=0;n<hi-lo;n++){int idx=lo+Math.floorMod(start+n,hi-lo);if((ownedMask&(1L<<idx))==0)return idx;}
        }
        for(int n=0;n<32;n++){int idx=(start+n)%32;if((ownedMask&(1L<<idx))==0)return idx;} return -1; }
    boolean isRareMonster(int idx){ return idx>=24&&idx<32; }
    int rareOwnedCount(){ int n=0; for(int i=24;i<32;i++)if((ownedMask&(1L<<i))!=0)n++; return n; }
    int pityRemaining(){ return Math.max(0,5-hatchPity); }
    boolean collectionComplete(){return Long.bitCount(ownedMask)>=32;}
    void resetStreak(Context c){streak=0;save(c);}
    int nextMissionTarget(){ return (missionRewardTier+1)*3; }
    boolean claimMissionReward(Context c){ int target=nextMissionTarget(); if(missionsDone<target)return false; missionRewardTier++; coins+=30; if(missionRewardTier%2==0)eggs++; achievementMask|=32L; save(c); return true; }
    void toggleSound(Context c){soundOn=soundOn==1?0:1;save(c);}
    void toggleVibration(Context c){vibrationOn=vibrationOn==1?0:1;save(c);}



    int unlockedStage(){
        int unlocked=1;
        for(int i=1;i<=30;i++){
            if(starsFor(i)>0) unlocked=Math.max(unlocked,Math.min(30,i+1));
        }
        return Math.max(1,Math.min(30,unlocked));
    }
    boolean isStageUnlocked(int level){ return level>=1 && level<=unlockedStage(); }
    int worldForStage(int level){ return Math.max(1,Math.min(3,((level-1)/10)+1)); }
    String worldName(int world){
        if(world==1) return "Bosque Sorridente";
        if(world==2) return "Ilhas de Açúcar";
        return "Céu das Estrelas";
    }
    int targetTapsForLevel(int level){
        if(isBoss(level)) return 10 + worldForStage(level)*2;
        return 6 + worldForStage(level);
    }
    int rewardForLevel(int level,int earnedStars){
        int base=8 + worldForStage(level)*4;
        if(isBoss(level)) base+=12;
        return base + Math.max(1,earnedStars)*3;
    }




    void validateReleaseState(){
        coins=Math.max(0,coins);
        eggs=Math.max(0,eggs);
        xp=Math.max(0,xp);
        playerLevel=Math.max(1,playerLevel);
        streak=Math.max(0,streak);
        bestStreak=Math.max(streak,bestStreak);
        bossTokens=Math.max(0,bossTokens);
        bossChestLevel=Math.max(0,bossChestLevel);
        friendshipLevel=Math.max(1,Math.min(6,friendshipLevel));
        reactionUses=Math.max(0,reactionUses);
        carePoints=Math.max(0,carePoints);
        houseLevel=Math.max(1,Math.min(5,houseLevel));
        hatchPity=Math.max(0,Math.min(5,hatchPity));
        favoriteMonster=Math.max(0,Math.min(MonsterCatalog.count()-1,favoriteMonster));
        normalizeLevelStars();
    }
    private void normalizeLevelStars(){
        if(levelStars==null || levelStars.isEmpty()) return;
        String[] raw=levelStars.split(",",-1);
        StringBuilder normalized=new StringBuilder();
        int count=Math.min(30,raw.length);
        for(int i=0;i<count;i++){
            if(i>0) normalized.append(',');
            normalized.append(Math.max(0,Math.min(3,parse(raw[i]))));
        }
        levelStars=normalized.toString();
    }

    int safeStage(int level){ return Math.max(1,Math.min(30,level)); }

    float textScale(){ return largeText==1 ? 1.18f : 1.0f; }
    boolean shouldAnimate(){ return reducedMotion==0; }
    int minimumTouchTargetDp(){ return 48; }
    String accessibilitySummary(){
        String a=largeText==1?"Texto grande":"Texto padrão";
        String b=reducedMotion==1?"Movimento reduzido":"Animações ativas";
        String c=highContrast==1?"Alto contraste":"Contraste padrão";
        return a+" • "+b+" • "+c;
    }

    String collectionMilestone(){
        int n=collectionCount();
        if(n>=32) return "Coleção completa!";
        if(n>=24) return "Explorador lendário: 24/32";
        if(n>=16) return "Grande colecionador: 16/32";
        if(n>=8) return "Colecionador iniciante: 8/32";
        return "Próximo marco: "+(8-n)+" monstrinho(s)";
    }
    int friendshipProgress(){ return Math.max(0,reactionUses%5); }
    int eggsUntilRare(){
        if(collectionCount()>=32) return 0;
        return Math.max(0,5-hatchPity);
    }
    int houseNextCare(){
        if(houseLevel>=5) return 0;
        return Math.max(0,houseLevel*5-carePoints);
    }

    String houseStage(){ String[] names={"Cantinho Fofo","Ninho Colorido","Casa Feliz","Mansão Monstrinha","Castelo da Amizade"}; return names[Math.max(0,Math.min(names.length-1,houseLevel-1))]; }
    int careGoal(){ return 5+houseLevel*3; }
    private int epochDay(){ return (int)(System.currentTimeMillis()/86400000L); }
    private void applyDailyNeedsDecay(int today){
        if(needsDay<=0){ needsDay=today; return; }
        int days=Math.max(0,Math.min(7,today-needsDay));
        if(days>0){ mood=Math.max(15,mood-days*6); hunger=Math.max(10,hunger-days*10); fun=Math.max(10,fun-days*8); needsDay=today; }
    }
    private void refreshCareDay(){ int d=epochDay(); applyDailyNeedsDecay(d); if(careDay!=d){ careDay=d; careToday=0; feedToday=0; playToday=0; } }
    int careLeftToday(){ refreshCareDay(); return Math.max(0,5-careToday); }
    boolean careAtHouse(Context c){
        refreshCareDay(); houseVisits++;
        if(careToday>=5){ save(c); return false; }
        careToday++; carePoints++; coins+=2; mood=Math.min(100,mood+12);
        applyCareEvolution();
        save(c); return true;
    }
    int feedLeftToday(){ refreshCareDay(); return Math.max(0,3-feedToday); }
    int playLeftToday(){ refreshCareDay(); return Math.max(0,3-playToday); }
    boolean feedAtHouse(Context c){
        refreshCareDay(); if(feedToday>=3 || coins<3)return false;
        coins-=3; feedToday++; carePoints+=2; houseVisits++; hunger=Math.min(100,hunger+18); mood=Math.min(100,mood+4);
        applyCareEvolution(); save(c); return true;
    }
    boolean playAtHouse(Context c){
        refreshCareDay(); if(playToday>=3)return false;
        playToday++; carePoints+=2; houseVisits++; fun=Math.min(100,fun+18); mood=Math.min(100,mood+6); if(playToday==3)coins+=3;
        applyCareEvolution(); save(c); return true;
    }
    private void applyCareEvolution(){
        if(carePoints>=careGoal()){ carePoints=0; coins+=10; if(houseLevel<5)houseLevel++; achievementMask|=1024L; }
    }

    String houseMood(){ int avg=(mood+hunger+fun)/3; return avg>=85?"Radiante":avg>=65?"Feliz":avg>=40?"Quer atenção":"Precisando de carinho"; }
    int houseWellbeing(){ return (mood+hunger+fun)/3; }
    String houseNeedHint(){ int m=Math.min(mood,Math.min(hunger,fun)); if(m==hunger)return "Seu amigo está com fome."; if(m==fun)return "Seu amigo quer brincar."; return "Seu amigo quer carinho."; }

    int decorCost(int idx){ return idx==1?35:idx==2?60:idx==3?90:0; }
    String decorName(){ String[] n={"Clássica","Floresta","Estrelas","Doce"}; return n[Math.max(0,Math.min(3,houseDecor))]; }
    boolean hasDecor(int idx){ return idx>=0&&idx<=3&&(houseDecorOwned&(1<<idx))!=0; }
    boolean selectOrBuyDecor(Context c,int idx){ if(idx<0||idx>3)return false; if(hasDecor(idx)){houseDecor=idx;save(c);return true;} int cost=decorCost(idx); if(coins<cost)return false; coins-=cost; houseDecorOwned|=(1<<idx); houseDecor=idx; if(Integer.bitCount(houseDecorOwned)>=4)achievementMask|=131072L; save(c); return true; }

    int bossChestCost(){ return 6 + bossChestLevel*2; }
    boolean claimBossChest(Context c){ int cost=bossChestCost(); if(bossTokens<cost)return false; bossTokens-=cost; bossChestLevel++; coins+=25+bossChestLevel*5; eggs++; if(bossChestLevel>=3)achievementMask|=32768L; save(c); return true; }

    void finishChallenge(Context c,int score){ challengeWins++; challengeBest=Math.max(challengeBest,score); coins+=5+Math.min(20,score); if(score>=10) achievementMask|=4096L; save(c); }
    int collectionCount(){return Long.bitCount(ownedMask);}
    int achievementCount(){ refreshMetaAchievement(); return Long.bitCount(achievementMask & ((1L<<AchievementCatalog.count())-1L)); }
    private void refreshMetaAchievement(){ long core=(1L<<19)-1L; if((achievementMask & core)==core) achievementMask|=(1L<<19); }
    int unlockedLevelCount(){ return Math.max(1,Math.min(30,level)); }
    boolean levelUnlocked(int n){ return n>=1&&n<=30&&n<=level; }
    boolean canUpgradeHouse(){ refreshCareDay(); return houseLevel<5 && houseWellbeing()>=60 && coins>=40*houseLevel; }
    String houseUpgradeHint(){ if(houseLevel>=5)return "Casinha no nível máximo!"; if(houseWellbeing()<60)return "Cuide do seu amigo até 60% de bem-estar."; int cost=40*houseLevel; if(coins<cost)return "Junte "+(cost-coins)+" moedas para evoluir."; return "Tudo pronto para evoluir!"; }
    boolean upgradeHouse(Context c){int cost=40*houseLevel;if(!canUpgradeHouse())return false;coins-=cost;houseLevel++;if(houseLevel>=3)achievementMask|=8L;save(c);return true;}
}
