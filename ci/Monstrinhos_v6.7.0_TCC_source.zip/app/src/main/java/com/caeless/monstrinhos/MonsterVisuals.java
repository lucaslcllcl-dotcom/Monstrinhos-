package com.caeless.monstrinhos;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;

/** Procedural character art: stable visual identity per monster id, no bitmap allocations. */
final class MonsterVisuals {
    private MonsterVisuals(){}

    static int bodyColor(int id, boolean accessible){
        if(accessible){
            int[] c={Color.rgb(35,105,180),Color.rgb(225,125,25),Color.rgb(55,145,80),Color.rgb(145,80,165)};
            return c[Math.floorMod(id,c.length)];
        }
        int[][] palette={
            {67,180,220},{245,121,139},{114,196,126},{150,114,215},
            {244,173,72},{74,160,220},{225,107,192},{88,194,176}
        };
        int[] v=palette[Math.floorMod(id,palette.length)];
        return Color.rgb(v[0],v[1],v[2]);
    }

    private static int darken(int color,float f){
        int r=Math.max(0,Math.min(255,(int)(Color.red(color)*f)));
        int g=Math.max(0,Math.min(255,(int)(Color.green(color)*f)));
        int b=Math.max(0,Math.min(255,(int)(Color.blue(color)*f)));
        return Color.rgb(r,g,b);
    }

    private static int lighten(int color,float f){
        int r=Math.max(0,Math.min(255,(int)(Color.red(color)+(255-Color.red(color))*f)));
        int g=Math.max(0,Math.min(255,(int)(Color.green(color)+(255-Color.green(color))*f)));
        int b=Math.max(0,Math.min(255,(int)(Color.blue(color)+(255-Color.blue(color))*f)));
        return Color.rgb(r,g,b);
    }

    static void draw(Canvas c, Paint p, float x, float y, float r, int id, boolean owned, boolean accessible){
        int body=owned?bodyColor(id,accessible):Color.rgb(177,182,191);
        int bodyDark=darken(body,.78f);
        int bodyLight=lighten(body,.34f);
        int shape=Math.floorMod(id,4);

        // Soft floor shadow gives the character depth without bitmap assets.
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(42,20,30,50));
        c.drawOval(x-r*.82f,y+r*.76f,x+r*.82f,y+r*1.05f,p);

        // Arms behind body.
        p.setColor(bodyDark);
        c.drawOval(x-r*1.04f,y+r*.08f,x-r*.58f,y+r*.62f,p);
        c.drawOval(x+r*.58f,y+r*.08f,x+r*1.04f,y+r*.62f,p);

        // Main body silhouette.
        p.setColor(body);
        if(shape==0)c.drawCircle(x,y,r,p);
        else if(shape==1)c.drawOval(x-r,y-r*.84f,x+r,y+r*.96f,p);
        else if(shape==2)c.drawRoundRect(x-r,y-r*.84f,x+r,y+r*.90f,r*.44f,r*.44f,p);
        else {
            Path b=new Path();
            b.moveTo(x,y-r);
            b.cubicTo(x+r*1.12f,y-r*.70f,x+r*1.04f,y+r*.90f,x,y+r);
            b.cubicTo(x-r*1.04f,y+r*.90f,x-r*1.12f,y-r*.70f,x,y-r);
            b.close();
            c.drawPath(b,p);
        }

        // Belly patch.
        p.setColor(bodyLight);
        c.drawOval(x-r*.52f,y+r*.20f,x+r*.52f,y+r*.82f,p);

        // Ears / side tufts make every monster friendlier and more recognizable.
        p.setColor(bodyDark);
        if((id&1)==0){
            Path l=new Path();l.moveTo(x-r*.66f,y-r*.63f);l.lineTo(x-r*.32f,y-r*1.34f);l.lineTo(x-r*.02f,y-r*.70f);l.close();c.drawPath(l,p);
            Path rr=new Path();rr.moveTo(x+r*.66f,y-r*.63f);rr.lineTo(x+r*.32f,y-r*1.34f);rr.lineTo(x+r*.02f,y-r*.70f);rr.close();c.drawPath(rr,p);
            p.setColor(lighten(body,.55f));
            Path li=new Path();li.moveTo(x-r*.49f,y-r*.72f);li.lineTo(x-r*.31f,y-r*1.14f);li.lineTo(x-r*.16f,y-r*.73f);li.close();c.drawPath(li,p);
            Path ri=new Path();ri.moveTo(x+r*.49f,y-r*.72f);ri.lineTo(x+r*.31f,y-r*1.14f);ri.lineTo(x+r*.16f,y-r*.73f);ri.close();c.drawPath(ri,p);
        }else{
            p.setColor(bodyDark);c.drawCircle(x-r*.73f,y-r*.61f,r*.32f,p);c.drawCircle(x+r*.73f,y-r*.61f,r*.32f,p);
            p.setColor(lighten(body,.55f));c.drawCircle(x-r*.73f,y-r*.61f,r*.15f,p);c.drawCircle(x+r*.73f,y-r*.61f,r*.15f,p);
        }

        // Small signature ornament.
        if(id%3==0){
            p.setColor(Color.rgb(255,214,66));
            c.drawCircle(x,y-r*.94f,r*.14f,p);
            p.setColor(Color.rgb(255,239,143));
            c.drawCircle(x-r*.04f,y-r*.99f,r*.045f,p);
        }else if(id%3==1){
            p.setColor(Color.rgb(255,235,122));
            Path star=new Path();star.moveTo(x,y-r*1.03f);star.lineTo(x+r*.08f,y-r*.84f);star.lineTo(x+r*.28f,y-r*.82f);star.lineTo(x+r*.12f,y-r*.70f);star.lineTo(x+r*.17f,y-r*.51f);star.lineTo(x,y-r*.61f);star.lineTo(x-r*.17f,y-r*.51f);star.lineTo(x-r*.12f,y-r*.70f);star.lineTo(x-r*.28f,y-r*.82f);star.lineTo(x-r*.08f,y-r*.84f);star.close();c.drawPath(star,p);
        }

        // Eyes with iris highlight.
        p.setColor(Color.WHITE);
        c.drawCircle(x-r*.34f,y-r*.18f,r*.22f,p); c.drawCircle(x+r*.34f,y-r*.18f,r*.22f,p);
        p.setColor(Color.rgb(42,53,77));
        c.drawCircle(x-r*.34f,y-r*.16f,r*.095f,p); c.drawCircle(x+r*.34f,y-r*.16f,r*.095f,p);
        p.setColor(Color.WHITE);
        c.drawCircle(x-r*.38f,y-r*.22f,r*.033f,p); c.drawCircle(x+r*.30f,y-r*.22f,r*.033f,p);

        // Rosy cheeks.
        p.setColor(Color.argb(150,255,122,145));
        c.drawCircle(x-r*.62f,y+r*.10f,r*.12f,p); c.drawCircle(x+r*.62f,y+r*.10f,r*.12f,p);

        if(!owned){
            p.setColor(Color.rgb(77,84,98)); p.setStrokeWidth(Math.max(2f,r*.08f)); p.setStyle(Paint.Style.STROKE);
            c.drawCircle(x,y,r*1.06f,p); p.setStyle(Paint.Style.FILL);
            return;
        }

        // Mouth: most monsters smile, a few use a playful open mouth.
        p.setColor(Color.rgb(85,48,74));
        if(id%4==3){
            c.drawOval(x-r*.27f,y+r*.18f,x+r*.27f,y+r*.48f,p);
            p.setColor(Color.rgb(255,132,153)); c.drawOval(x-r*.16f,y+r*.32f,x+r*.16f,y+r*.46f,p);
        }else{
            p.setStrokeWidth(Math.max(2f,r*.07f)); p.setStyle(Paint.Style.STROKE);
            c.drawArc(x-r*.30f,y+r*.10f,x+r*.30f,y+r*.47f,8,164,false,p);
            p.setStyle(Paint.Style.FILL);
        }

        // Tiny feet.
        p.setColor(bodyDark);
        c.drawOval(x-r*.56f,y+r*.70f,x-r*.10f,y+r*1.00f,p);
        c.drawOval(x+r*.10f,y+r*.70f,x+r*.56f,y+r*1.00f,p);

        if(MonsterCatalog.rare(id)){
            p.setColor(Color.rgb(255,205,55)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(3f,r*.08f));
            c.drawCircle(x,y,r*1.20f,p); p.setStyle(Paint.Style.FILL);
        }
    }
}
