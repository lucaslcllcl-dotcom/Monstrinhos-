package com.caeless.monstrinhos;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.view.View;

public final class MainActivity extends Activity {
    private MonstrinhosView gameView;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        hideSystemUi();
        gameView=new MonstrinhosView(this);
        if(b!=null) gameView.restoreSession(b);
        setContentView(gameView);
    }
    private void hideSystemUi(){
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }
    @Override public void onWindowFocusChanged(boolean hasFocus){
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus) hideSystemUi();
    }
    @Override protected void onSaveInstanceState(Bundle out){
        if(gameView!=null) gameView.saveSession(out);
        super.onSaveInstanceState(out);
    }
    @Override protected void onPause(){
        if(gameView!=null) gameView.persistProgress();
        super.onPause();
    }
}
