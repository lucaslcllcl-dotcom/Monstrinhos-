package com.caeless.monstrinhos;

/** Stable IDs for the 32 collectible Monstrinhos. Never reorder: ownedMask uses these indexes. */
final class MonsterCatalog {
    private static final String[] NAMES={
        "Pingo","Lumi","Tico","Bibi","Nino","Mimi","Puff","Zuzu",
        "Kiko","Lilo","Tutu","Fifi","Balu","Nana","Gigi","Dudu",
        "Pipoca","Faísca","Jujuba","Bolota","Nuvem","Pitanga","Cacau","Amora",
        "Aurora","Cometa","Cristal","Fênix","Nebulino","Estelar","Prisma","Solzinho"
    };
    static int count(){ return NAMES.length; }
    static String name(int id){ return id>=0&&id<NAMES.length?NAMES[id]:"Monstrinho"; }
    static boolean rare(int id){ return id>=24&&id<32; }
    static String rarity(int id){ return rare(id)?"RARO":"COMUM"; }
    static String description(int id){
        if(rare(id)) return "Um amigo raro cheio de brilho e personalidade!";
        String[] traits={"adora brincar","ama aprender","é muito curioso","gosta de ajudar","vive sorrindo","adora aventuras"};
        return "Um novo amigo que "+traits[Math.floorMod(id,traits.length)]+".";
    }
    private MonsterCatalog(){}
}
