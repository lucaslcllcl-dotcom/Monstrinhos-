package com.caeless.monstrinhos;

/** Stable metadata for the six milestone bosses. IDs are derived from stage number. */
final class BossCatalog {
    private static final String[] NAMES={"Rei Gelatina","Dona Trovoada","Capitão Pipoca","Dragão Marshmallow","Bruxa Confete","Guardião Estelar"};
    private static final String[] TRAITS={
        "Pula de um lado para o outro.","Adora mudanças rápidas.","Estoura quando fica animado.",
        "É grandão, mas muito amigável.","Espalha confetes pelo caminho.","Protege a última estrela do céu."
    };
    private BossCatalog(){}
    static int indexForStage(int stage){ return Math.max(0,Math.min(5,stage/5-1)); }
    static String name(int stage){ return NAMES[indexForStage(stage)]; }
    static String trait(int stage){ return TRAITS[indexForStage(stage)]; }
    static int target(int stage){ return 8; }
    static int tokenReward(int stars){ return Math.max(1,Math.min(3,stars)); }
}
