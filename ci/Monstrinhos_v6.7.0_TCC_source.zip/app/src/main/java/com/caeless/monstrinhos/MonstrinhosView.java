package com.caeless.monstrinhos;

import android.content.Context;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import java.util.Random;

final class MonstrinhosView extends View {
    private final Paint p=new Paint(3); private final Random rng=new Random(); private final GameState s;
    private final Bitmap refHomePortrait,refHomeLandscape,refMap,refSettings,refAchievements,refGameplay,refAlbum,refHatch,refHouse;
    private int screen=0,taps=0,selectedLevel=1,misses=0,challengeScore=0,albumPage=0,levelPage=0; private float targetX=.50f,targetY=.50f; private String reaction="";
    MonstrinhosView(Context c){
        super(c);
        s=GameState.load(c);
        setFocusable(true);
        setContentDescription("Monstrinhos. Jogo infantil com fases, coleção, ovos e casinha.");
        p.setTypeface(Typeface.create("sans",Typeface.BOLD));
        refHomePortrait=BitmapFactory.decodeResource(getResources(),R.drawable.ref_home_portrait);
        refHomeLandscape=BitmapFactory.decodeResource(getResources(),R.drawable.ref_home_landscape);
        refMap=BitmapFactory.decodeResource(getResources(),R.drawable.ref_map);
        refSettings=BitmapFactory.decodeResource(getResources(),R.drawable.ref_settings);
        refAchievements=BitmapFactory.decodeResource(getResources(),R.drawable.ref_achievements);
        refGameplay=BitmapFactory.decodeResource(getResources(),R.drawable.ref_gameplay);
        refAlbum=BitmapFactory.decodeResource(getResources(),R.drawable.ref_album);
        refHatch=BitmapFactory.decodeResource(getResources(),R.drawable.ref_hatch);
        refHouse=BitmapFactory.decodeResource(getResources(),R.drawable.ref_house);
        moveTccTarget();
    }
    void persistProgress(){ s.save(getContext()); }
    void saveSession(Bundle out){
        out.putInt("ui_screen",screen); out.putInt("ui_taps",taps); out.putInt("ui_selected_level",selectedLevel);
        out.putInt("ui_misses",misses); out.putInt("ui_challenge_score",challengeScore); out.putInt("ui_album_page",albumPage); out.putInt("ui_level_page",levelPage);
        out.putFloat("ui_target_x",targetX); out.putFloat("ui_target_y",targetY); out.putString("ui_reaction",reaction);
    }
    void restoreSession(Bundle in){
        screen=clamp(in.getInt("ui_screen",0),0,12); taps=Math.max(0,in.getInt("ui_taps",0)); selectedLevel=clamp(in.getInt("ui_selected_level",1),1,30);
        misses=clamp(in.getInt("ui_misses",0),0,3); challengeScore=Math.max(0,in.getInt("ui_challenge_score",0)); albumPage=clamp(in.getInt("ui_album_page",0),0,1); levelPage=clamp(in.getInt("ui_level_page",0),0,2);
        targetX=clampF(in.getFloat("ui_target_x",.5f),.1f,.9f); targetY=clampF(in.getFloat("ui_target_y",.55f),.2f,.8f); reaction=in.getString("ui_reaction","");
        invalidate();
    }
    private int clamp(int v,int lo,int hi){return Math.max(lo,Math.min(hi,v));}
    private float clampF(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private void drawRef(Canvas c,Bitmap b,float w,float h){
        if(b==null){c.drawColor(Color.rgb(234,248,255));return;}
        p.setAlpha(255); p.setFilterBitmap(true);
        c.drawBitmap(b,null,new RectF(0,0,w,h),p);
    }
    private void moveTccTarget(){
        final float[][] pts={{.50f,.48f},{.20f,.38f},{.80f,.39f},{.20f,.58f},{.43f,.68f},{.78f,.62f}};
        float[] q=pts[rng.nextInt(pts.length)]; targetX=q[0]; targetY=q[1];
    }
    private void drawTccGameplayOverlay(Canvas c,float w,float h){
        int need=s.isBoss(selectedLevel)?BossCatalog.target(selectedLevel):8;
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(5f,Math.min(w,h)*.012f)); p.setColor(0xccffd43b);
        c.drawCircle(w*targetX,h*targetY,Math.min(w,h)*.075f,p); p.setStyle(Paint.Style.FILL);
        drawPill(c,w*.24f,h*.80f,w*.76f,h*.865f,0xd92a3344,0xfff6c54d);
        text(c,"ACERTOS  "+taps+" / "+need+"   •   ❤ "+Math.max(0,3-misses),w*.50f,h*.842f,17,Color.WHITE);
        drawPill(c,w*.38f,h*.91f,w*.62f,h*.965f,0xdd1f4d85,0xffdcecff);
        text(c,"SAIR",w*.50f,h*.945f,15,Color.WHITE);
    }
    private void text(Canvas c,String t,float x,float y,float size,int color){p.setTextSize(size*s.textScale());p.setColor(color);p.setTextAlign(Paint.Align.CENTER);c.drawText(t,x,y,p);}
    private void button(Canvas c,String t,float l,float top,float r,float b,int color){p.setColor(color);c.drawRoundRect(l,top,r,b,28,28,p);text(c,t,(l+r)/2,(top+b)/2+11,Math.min(32,(b-top)*.34f),Color.WHITE);}
    private void monster(Canvas c,float x,float y,float r,int color){if(s.colorBlindMode==1) color=Color.rgb(40,120,190);p.setColor(color);c.drawCircle(x,y,r,p);p.setColor(Color.WHITE);c.drawCircle(x-r*.35f,y-r*.2f,r*.17f,p);c.drawCircle(x+r*.35f,y-r*.2f,r*.17f,p);p.setColor(Color.DKGRAY);c.drawCircle(x-r*.35f,y-r*.2f,r*.07f,p);c.drawCircle(x+r*.35f,y-r*.2f,r*.07f,p);}

    private void textLeft(Canvas c,String t,float x,float y,float size,int color){p.setTextSize(size*s.textScale());p.setColor(color);p.setTextAlign(Paint.Align.LEFT);c.drawText(t,x,y,p);}    
    private void drawPill(Canvas c,float l,float top,float r,float b,int fill,int stroke){p.setStyle(Paint.Style.FILL);p.setColor(fill);c.drawRoundRect(l,top,r,b,(b-top)*.5f,(b-top)*.5f,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(2f,(b-top)*.05f));p.setColor(stroke);c.drawRoundRect(l,top,r,b,(b-top)*.5f,(b-top)*.5f,p);p.setStyle(Paint.Style.FILL);}    
    private void drawSoftPanel(Canvas c,float l,float top,float r,float b,int fill,int stroke){p.setStyle(Paint.Style.FILL);p.setColor(0x22000000);c.drawRoundRect(l+4,top+8,r+4,b+8,32,32,p);p.setColor(fill);c.drawRoundRect(l,top,r,b,32,32,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3f);p.setColor(stroke);c.drawRoundRect(l,top,r,b,32,32,p);p.setStyle(Paint.Style.FILL);}    
    private void drawMenuButton(Canvas c,String icon,String label,float l,float top,float r,float b,int fill,int stroke){drawSoftPanel(c,l,top,r,b,fill,stroke);p.setTextAlign(Paint.Align.CENTER);text(c,icon,(l+r)/2,(top+b)/2-8,28,Color.WHITE);text(c,label,(l+r)/2,(top+b)/2+26,18,Color.WHITE);}    
    private void drawSkyCloud(Canvas c,float x,float y,float s0){p.setColor(0xeeffffff);c.drawCircle(x-s0*.24f,y,s0*.18f,p);c.drawCircle(x,y-s0*.08f,s0*.22f,p);c.drawCircle(x+s0*.24f,y,s0*.17f,p);c.drawRoundRect(x-s0*.42f,y-s0*.02f,x+s0*.42f,y+s0*.17f,s0*.12f,s0*.12f,p);}    
    private void drawHomeScene(Canvas c,float w,float h){
        c.drawColor(Color.rgb(139,211,255));
        p.setShader(new LinearGradient(0,0,0,h*0.72f,Color.rgb(128,205,255),Color.rgb(215,244,255),Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p); p.setShader(null);
        drawSkyCloud(c,w*.18f,h*.09f,w*.12f); drawSkyCloud(c,w*.73f,h*.11f,w*.10f);
        p.setColor(Color.rgb(184,214,230)); Path m1=new Path(); m1.moveTo(-w*.05f,h*.56f); m1.lineTo(w*.18f,h*.28f); m1.lineTo(w*.39f,h*.56f); m1.close(); c.drawPath(m1,p);
        p.setColor(Color.rgb(142,175,198)); Path m2=new Path(); m2.moveTo(w*.18f,h*.58f); m2.lineTo(w*.44f,h*.18f); m2.lineTo(w*.69f,h*.58f); m2.close(); c.drawPath(m2,p);
        p.setColor(Color.rgb(122,160,186)); Path m3=new Path(); m3.moveTo(w*.52f,h*.58f); m3.lineTo(w*.79f,h*.24f); m3.lineTo(w*1.02f,h*.58f); m3.close(); c.drawPath(m3,p);
        p.setColor(Color.WHITE); Path snow=new Path(); snow.moveTo(w*.34f,h*.27f); snow.lineTo(w*.39f,h*.18f); snow.lineTo(w*.44f,h*.27f); snow.lineTo(w*.49f,h*.20f); snow.lineTo(w*.54f,h*.27f); snow.lineTo(w*.49f,h*.31f); snow.lineTo(w*.44f,h*.27f); snow.lineTo(w*.39f,h*.31f); snow.close(); c.drawPath(snow,p);
        p.setColor(Color.rgb(95,189,101)); Path hill1=new Path(); hill1.moveTo(0,h*.63f); hill1.quadTo(w*.18f,h*.54f,w*.34f,h*.61f); hill1.quadTo(w*.52f,h*.68f,w*.72f,h*.60f); hill1.quadTo(w*.9f,h*.53f,w,h*.60f); hill1.lineTo(w,h); hill1.lineTo(0,h); hill1.close(); c.drawPath(hill1,p);
        p.setColor(Color.rgb(129,220,98)); Path hill2=new Path(); hill2.moveTo(0,h*.71f); hill2.quadTo(w*.22f,h*.61f,w*.42f,h*.69f); hill2.quadTo(w*.67f,h*.77f,w,h*.67f); hill2.lineTo(w,h); hill2.lineTo(0,h); hill2.close(); c.drawPath(hill2,p);
        for(float tx: new float[]{w*.08f,w*.16f,w*.28f,w*.39f,w*.64f,w*.79f,w*.9f}){p.setColor(Color.rgb(125,88,52));c.drawRoundRect(tx,h*.74f,tx+w*.018f,h*.83f,8,8,p);p.setColor(Color.rgb(58,189,92));c.drawCircle(tx+w*.009f,h*.72f,w*.028f,p);c.drawCircle(tx-w*.01f,h*.73f,w*.022f,p);c.drawCircle(tx+w*.028f,h*.73f,w*.02f,p);}        
        float hx=w*.72f, hy=h*.34f, hw=w*.19f, hh=h*.28f;
        p.setColor(Color.rgb(237,214,165)); c.drawRoundRect(hx,hy,hx+hw,hy+hh,22,22,p);
        p.setColor(Color.rgb(227,84,67)); Path roof=new Path(); roof.moveTo(hx-w*.03f,hy+h*.02f); roof.lineTo(hx+hw*.5f,hy-h*.09f); roof.lineTo(hx+hw+w*.03f,hy+h*.02f); roof.close(); c.drawPath(roof,p);
        p.setColor(Color.rgb(170,110,52)); c.drawRoundRect(hx+hw*.38f,hy+hh*.58f,hx+hw*.62f,hy+hh,18,18,p);
        p.setColor(Color.rgb(157,208,255)); c.drawRoundRect(hx+hw*.14f,hy+hh*.22f,hx+hw*.34f,hy+hh*.38f,10,10,p); c.drawRoundRect(hx+hw*.66f,hy+hh*.22f,hx+hw*.86f,hy+hh*.38f,10,10,p);
    }
    private void drawHomeHud(Canvas c,float w,float h){
        drawSoftPanel(c,w*.03f,h*.02f,w*.38f,h*.11f,Color.argb(242,246,249,255),Color.rgb(191,219,255));
        MonsterVisuals.draw(c,p,w*.10f,h*.065f,Math.min(w,h)*.04f,s.favoriteMonster,true,s.colorBlindMode==1);
        textLeft(c,"Olá, Amigo!",w*.16f,h*.055f,18,Color.rgb(42,60,120));
        textLeft(c,"Nível "+s.playerLevel+"  •  "+s.collectionCount()+"/32",w*.16f,h*.083f,12,Color.rgb(70,85,120));
        drawPill(c,w*.42f,h*.025f,w*.58f,h*.085f,Color.rgb(39,58,121),Color.rgb(24,38,86));
        text(c,"🪙 "+s.coins,w*.50f,h*.063f,18,Color.WHITE);
        drawPill(c,w*.62f,h*.025f,w*.77f,h*.085f,Color.rgb(39,58,121),Color.rgb(24,38,86));
        text(c,"🥚 "+s.eggs,w*.695f,h*.063f,18,Color.WHITE);
        drawSoftPanel(c,w*.84f,h*.02f,w*.97f,h*.11f,Color.rgb(34,136,231),Color.rgb(21,96,176));
        text(c,"⚙",w*.905f,h*.058f,24,Color.WHITE); text(c,"OPÇÕES",w*.905f,h*.088f,10,Color.WHITE);
    }
    private void drawLogo(Canvas c,float w,float h){ p.setTextSize(Math.min(54f,Math.max(42f,w*.072f))*s.textScale()); p.setTextAlign(Paint.Align.CENTER); p.setColor(0x44000000); c.drawText("MONSTRINHOS",w*.5f+3,h*.20f+3,p); p.setColor(Color.rgb(255,211,43)); c.drawText("MONSTRINHOS",w*.5f,h*.20f,p); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(7f); p.setColor(Color.rgb(102,45,170)); c.drawText("MONSTRINHOS",w*.5f,h*.20f,p); p.setStyle(Paint.Style.FILL); text(c,"Pequenas criaturas, grandes aventuras!",w*.5f,h*.245f,16,Color.rgb(88,65,55)); }
    private void drawGameplayScene(Canvas c,float w,float h,boolean boss){
        p.setShader(new LinearGradient(0,0,0,h*.72f,Color.rgb(108,196,255),Color.rgb(222,246,255),Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);
        drawSkyCloud(c,w*.18f,h*.15f,w*.10f);drawSkyCloud(c,w*.76f,h*.20f,w*.08f);
        p.setColor(Color.rgb(96,193,96));c.drawRoundRect(0,h*.70f,w,h,0,0,p);
        p.setColor(Color.rgb(74,151,78));for(int i=0;i<6;i++){float x=w*(.03f+i*.19f);c.drawCircle(x,h*.70f,w*.045f,p);}
        p.setColor(Color.rgb(151,104,59));c.drawRect(w*.04f,h*.72f,w*.96f,h*.755f,p);
        p.setColor(Color.rgb(83,171,91));c.drawRoundRect(w*.04f,h*.68f,w*.96f,h*.72f,18,18,p);
        if(boss){p.setColor(0x33a030c0);c.drawCircle(w*.50f,h*.48f,w*.22f,p);}
    }
    private void drawProgressBar(Canvas c,float l,float top,float r,float b,int value,int max,int fill){drawPill(c,l,top,r,b,Color.argb(220,233,239,245),Color.rgb(145,157,169));float frac=max<=0?0f:Math.max(0f,Math.min(1f,value/(float)max));p.setColor(fill);c.drawRoundRect(l+3,top+3,l+3+(r-l-6)*frac,b-3,(b-top)*.5f,(b-top)*.5f,p);}
    private void drawEgg(Canvas c,float x,float y,float rx,float ry,int shell,int accent){p.setColor(shell);c.drawOval(x-rx,y-ry,x+rx,y+ry,p);p.setColor(accent);c.drawCircle(x-rx*.35f,y-ry*.15f,rx*.18f,p);c.drawCircle(x+rx*.30f,y-ry*.30f,rx*.14f,p);c.drawCircle(x+rx*.12f,y+ry*.25f,rx*.12f,p);}
    private boolean isLandscape(float w,float h){return w>h*1.08f;}
    private void drawGuideCard(Canvas c,String title,String body,float l,float top,float r,float b,int fill,int stroke){drawSoftPanel(c,l,top,r,b,fill,stroke);text(c,title,(l+r)/2,top+(b-top)*.38f,16,Color.rgb(73,63,123));text(c,body,(l+r)/2,top+(b-top)*.68f,11,Color.rgb(86,82,92));}
    private void drawHomePortrait(Canvas c,float w,float h){
        drawHomeScene(c,w,h); drawHomeHud(c,w,h); drawLogo(c,w,h);
        drawPill(c,w*.27f,h*.25f,w*.73f,h*.305f,Color.argb(245,255,250,232),Color.rgb(162,125,79));
        text(c,"AVENTURA • FASE "+s.level,w*.50f,h*.286f,18,Color.rgb(110,69,42));
        drawSoftPanel(c,w*.22f,h*.32f,w*.78f,h*.47f,Color.argb(242,255,253,245),Color.rgb(198,185,144));
        MonsterVisuals.draw(c,p,w*.50f,h*.378f,Math.min(w,h)*.078f,s.favoriteMonster,true,s.colorBlindMode==1);
        text(c,"Seu monstrinho está pronto para brincar!",w*.50f,h*.447f,13,Color.rgb(93,84,110));
        drawMenuButton(c,"📘","GUIA",w*.05f,h*.35f,w*.25f,h*.43f,Color.argb(245,115,182,212),Color.rgb(74,118,150));
        drawMenuButton(c,"🏠","CASINHA",w*.75f,h*.35f,w*.95f,h*.43f,Color.argb(245,235,203,124),Color.rgb(154,117,64));
        if(!reaction.isEmpty()) drawPill(c,w*.18f,h*.485f,w*.82f,h*.53f,Color.argb(238,245,240,255),Color.rgb(159,132,212));
        if(!reaction.isEmpty()) text(c,reaction,w/2,h*.514f,13,Color.rgb(80,60,150));
        drawMenuButton(c,"▶","JOGAR",w*.14f,h*.54f,w*.86f,h*.62f,Color.argb(246,80,184,95),Color.rgb(42,113,49));
        drawMenuButton(c,"🎁","PRESENTE",w*.05f,h*.65f,w*.31f,h*.73f,s.dailyAvailable()?Color.argb(245,118,187,129):Color.argb(245,133,145,139),Color.rgb(81,100,78));
        drawMenuButton(c,"🥚",s.incubatorReady()?"OVO PRONTO":"OVO",w*.37f,h*.65f,w*.63f,h*.73f,Color.argb(245,97,129,208),Color.rgb(67,85,143));
        drawMenuButton(c,"🛍","LOJA",w*.69f,h*.65f,w*.95f,h*.73f,Color.argb(245,121,123,173),Color.rgb(73,74,116));
        drawMenuButton(c,"📖","ÁLBUM",w*.05f,h*.76f,w*.31f,h*.84f,Color.argb(245,96,183,169),Color.rgb(59,113,105));
        drawMenuButton(c,"🏠","CASINHA",w*.37f,h*.76f,w*.63f,h*.84f,Color.argb(245,157,172,83),Color.rgb(115,125,53));
        drawMenuButton(c,"⚙","AJUSTES",w*.69f,h*.76f,w*.95f,h*.84f,Color.argb(245,72,112,90),Color.rgb(44,72,58));
        drawMenuButton(c,"🏆","CONQUISTAS",w*.12f,h*.845f,w*.88f,h*.905f,Color.argb(245,163,178,78),Color.rgb(116,131,52));
        drawMenuButton(c,"🏁","DESAFIO RÁPIDO",w*.18f,h*.915f,w*.82f,h*.965f,Color.argb(245,107,132,128),Color.rgb(67,82,79));
        text(c,"v6.6.1",w*.93f,h*.955f,9,Color.rgb(45,70,85));
    }
    private void drawHomeLandscape(Canvas c,float w,float h){
        drawHomeScene(c,w,h); drawHomeHud(c,w,h);
        p.setTextSize(32*s.textScale()); p.setTextAlign(Paint.Align.CENTER); p.setColor(0x44000000); c.drawText("MONSTRINHOS",w*.50f+3,h*.18f+3,p); p.setColor(Color.rgb(255,211,43)); c.drawText("MONSTRINHOS",w*.50f,h*.18f,p); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(6f); p.setColor(Color.rgb(102,45,170)); c.drawText("MONSTRINHOS",w*.50f,h*.18f,p); p.setStyle(Paint.Style.FILL); text(c,"Pequenas criaturas, grandes aventuras!",w*.50f,h*.23f,13,Color.rgb(88,65,55));
        drawPill(c,w*.33f,h*.25f,w*.67f,h*.315f,Color.argb(245,255,250,232),Color.rgb(162,125,79));
        text(c,"AVENTURA • FASE "+s.level,w*.50f,h*.292f,18,Color.rgb(110,69,42));
        drawMenuButton(c,"📘","GUIA",w*.06f,h*.33f,w*.29f,h*.44f,Color.argb(245,115,182,212),Color.rgb(74,118,150));
        drawMenuButton(c,"🏠","CASINHA",w*.71f,h*.33f,w*.94f,h*.44f,Color.argb(245,235,203,124),Color.rgb(154,117,64));
        drawSoftPanel(c,w*.35f,h*.34f,w*.65f,h*.53f,Color.argb(242,255,253,245),Color.rgb(198,185,144));
        MonsterVisuals.draw(c,p,w*.50f,h*.435f,Math.min(w,h)*.10f,s.favoriteMonster,true,s.colorBlindMode==1);
        if(!reaction.isEmpty()) drawPill(c,w*.31f,h*.54f,w*.69f,h*.595f,Color.argb(238,245,240,255),Color.rgb(159,132,212));
        if(!reaction.isEmpty()) text(c,reaction,w/2,h*.575f,12,Color.rgb(80,60,150));
        drawMenuButton(c,"▶","JOGAR",w*.18f,h*.56f,w*.82f,h*.66f,Color.argb(246,80,184,95),Color.rgb(42,113,49));
        drawMenuButton(c,"🏁","DESAFIO RÁPIDO",w*.33f,h*.67f,w*.67f,h*.75f,Color.argb(245,107,132,128),Color.rgb(67,82,79));
        drawMenuButton(c,"🎁","PRESENTE",w*.05f,h*.76f,w*.30f,h*.86f,s.dailyAvailable()?Color.argb(245,118,187,129):Color.argb(245,133,145,139),Color.rgb(81,100,78));
        drawMenuButton(c,"🥚",s.incubatorReady()?"OVO PRONTO":"OVO",w*.37f,h*.76f,w*.63f,h*.86f,Color.argb(245,97,129,208),Color.rgb(67,85,143));
        drawMenuButton(c,"🛍","LOJA",w*.70f,h*.76f,w*.95f,h*.86f,Color.argb(245,121,123,173),Color.rgb(73,74,116));
        drawMenuButton(c,"📖","ÁLBUM",w*.05f,h*.87f,w*.30f,h*.97f,Color.argb(245,96,183,169),Color.rgb(59,113,105));
        drawMenuButton(c,"🏆","CONQUISTAS",w*.37f,h*.87f,w*.63f,h*.97f,Color.argb(245,163,178,78),Color.rgb(116,131,52));
        drawMenuButton(c,"⚙","AJUSTES",w*.70f,h*.87f,w*.95f,h*.97f,Color.argb(245,72,112,90),Color.rgb(44,72,58));
        text(c,"v6.6.1",w*.95f,h*.955f,9,Color.rgb(45,70,85));
    }
    private void drawGuidePortrait(Canvas c,float w,float h){
        drawHomeScene(c,w,h);
        drawSoftPanel(c,w*.09f,h*.08f,w*.91f,h*.19f,Color.argb(240,255,252,246),Color.rgb(186,160,222));
        text(c,"GUIA DOS MONSTRINHOS",w/2,h*.127f,26,Color.rgb(104,71,162));
        text(c,"Aprenda brincando em menos de 1 minuto",w/2,h*.165f,12,Color.rgb(88,84,96));
        MonsterVisuals.draw(c,p,w*.50f,h*.28f,Math.min(w,h)*.095f,s.favoriteMonster,true,s.colorBlindMode==1);
        drawGuideCard(c,"1. TOQUE COM PRECISÃO","Acerte o monstrinho e ganhe até 3 estrelas por fase.",w*.08f,h*.34f,w*.92f,h*.425f,Color.argb(242,247,243,255),Color.rgb(172,156,214));
        drawGuideCard(c,"2. GANHE OVOS E AMIGOS","Colecione 32 monstrinhos diferentes no álbum.",w*.08f,h*.445f,w*.92f,h*.53f,Color.argb(242,255,249,235),Color.rgb(210,179,118));
        drawGuideCard(c,"3. CUIDE DA CASINHA","Carinho, comida e brincadeiras fazem tudo evoluir.",w*.08f,h*.55f,w*.92f,h*.635f,Color.argb(242,236,252,242),Color.rgb(126,180,136));
        drawGuideCard(c,"4. DERROTE CHEFES","Chefes aparecem a cada 5 fases com baús especiais.",w*.08f,h*.655f,w*.92f,h*.74f,Color.argb(242,243,240,255),Color.rgb(163,150,217));
        drawPill(c,w*.10f,h*.765f,w*.90f,h*.81f,Color.argb(236,248,244,255),Color.rgb(164,144,212));
        text(c,"Dica: se errar muito, o alvo fica mais amigável para ajudar você.",w/2,h*.793f,12,Color.rgb(80,60,150));
        drawMenuButton(c,"▶","ENTENDI • VAMOS JOGAR",w*.14f,h*.86f,w*.86f,h*.94f,Color.argb(246,80,190,145),Color.rgb(49,131,103));
    }
    private void drawGuideLandscape(Canvas c,float w,float h){
        drawHomeScene(c,w,h);
        drawSoftPanel(c,w*.04f,h*.11f,w*.32f,h*.80f,Color.argb(240,255,252,246),Color.rgb(186,160,222));
        text(c,"GUIA DOS",w*.18f,h*.20f,23,Color.rgb(104,71,162)); text(c,"MONSTRINHOS",w*.18f,h*.25f,23,Color.rgb(104,71,162));
        MonsterVisuals.draw(c,p,w*.18f,h*.43f,Math.min(w,h)*.14f,s.favoriteMonster,true,s.colorBlindMode==1);
        text(c,"Toque, colecione, cuide da casinha",w*.18f,h*.62f,11,Color.rgb(88,84,96));
        text(c,"e vença chefes especiais!",w*.18f,h*.66f,11,Color.rgb(88,84,96));
        drawGuideCard(c,"TOQUE COM PRECISÃO","Acerte o monstrinho e some até 3 estrelas.",w*.38f,h*.14f,w*.68f,h*.31f,Color.argb(242,247,243,255),Color.rgb(172,156,214));
        drawGuideCard(c,"GANHE OVOS","Abra ovos, descubra amigos e complete o álbum.",w*.71f,h*.14f,w*.96f,h*.31f,Color.argb(242,255,249,235),Color.rgb(210,179,118));
        drawGuideCard(c,"CASINHA EVOLUI","Dê carinho, comida e diversão ao seu amigo.",w*.38f,h*.38f,w*.68f,h*.55f,Color.argb(242,236,252,242),Color.rgb(126,180,136));
        drawGuideCard(c,"CHEFES E BAÚS","A cada 5 fases, um chefe libera grandes prêmios.",w*.71f,h*.38f,w*.96f,h*.55f,Color.argb(242,243,240,255),Color.rgb(163,150,217));
        drawPill(c,w*.38f,h*.62f,w*.96f,h*.70f,Color.argb(236,248,244,255),Color.rgb(164,144,212));
        text(c,"Dica: se errar demais, o jogo ajuda e o alvo fica mais fácil.",w*.67f,h*.672f,12,Color.rgb(80,60,150));
        drawMenuButton(c,"▶","ENTENDI • VAMOS JOGAR",w*.56f,h*.79f,w*.95f,h*.92f,Color.argb(246,80,190,145),Color.rgb(49,131,103));
    }

    private float stageX(float w,float h,int slot){
        if(isLandscape(w,h)){
            int col=slot<5?slot:9-slot;
            return w*(.12f+col*.19f);
        }
        int col=slot<5?slot:9-slot;
        return w*(.14f+col*.18f);
    }
    private float stageY(float w,float h,int slot){
        if(isLandscape(w,h)) return h*(slot<5?.37f:.58f)+((slot%2==0)?-h*.025f:h*.025f);
        return h*(slot<5?.34f:.55f)+((slot%2==0)?-h*.018f:h*.018f);
    }
    private void drawStageNode(Canvas c,float x,float y,float r,int level,boolean unlocked,boolean boss){
        int fill=unlocked?(boss?Color.rgb(174,94,205):Color.rgb(66,164,232)):Color.rgb(184,194,202);
        int stroke=unlocked?(boss?Color.rgb(112,55,143):Color.rgb(42,108,176)):Color.rgb(125,137,145);
        p.setStyle(Paint.Style.FILL); p.setColor(0x26000000); c.drawCircle(x+4,y+7,r,p);
        p.setColor(fill); c.drawCircle(x,y,r,p);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(3f,r*.10f));p.setColor(stroke);c.drawCircle(x,y,r,p);p.setStyle(Paint.Style.FILL);
        if(boss){p.setColor(Color.rgb(255,216,74));Path crown=new Path();crown.moveTo(x-r*.45f,y-r*.35f);crown.lineTo(x-r*.22f,y-r*.72f);crown.lineTo(x,y-r*.42f);crown.lineTo(x+r*.22f,y-r*.72f);crown.lineTo(x+r*.45f,y-r*.35f);crown.close();c.drawPath(crown,p);}
        text(c,String.valueOf(level),x,y+7,Math.max(14,r*.48f),Color.WHITE);
        text(c,unlocked?(boss?"CHEFE":"★ "+s.starsFor(level)):"🔒",x,y+r*.78f,Math.max(9,r*.22f),unlocked?Color.WHITE:Color.rgb(95,105,115));
    }
    private void drawMapScreen(Canvas c,float w,float h){
        drawRef(c,refMap,w,h);
        text(c,"Fase atual: "+s.level+"   •   Estrelas: "+s.stars,w*.50f,h*.865f,13,0xff5a391e);
    }
    private void drawHouseRoom(Canvas c,float l,float top,float r,float b){
        drawSoftPanel(c,l,top,r,b,Color.rgb(255,247,226),Color.rgb(185,145,92));
        float mid=top+(b-top)*.58f;
        p.setColor(Color.rgb(247,225,183));c.drawRect(l+3,top+3,r-3,mid,p);
        p.setColor(Color.rgb(210,169,112));c.drawRect(l+3,mid,r-3,b-3,p);
        // window
        p.setColor(Color.rgb(134,203,244));c.drawRoundRect(l+(r-l)*.08f,top+(b-top)*.12f,l+(r-l)*.31f,top+(b-top)*.40f,12,12,p);
        p.setColor(Color.WHITE);c.drawRect(l+(r-l)*.19f,top+(b-top)*.12f,l+(r-l)*.205f,top+(b-top)*.40f,p);c.drawRect(l+(r-l)*.08f,top+(b-top)*.255f,l+(r-l)*.31f,top+(b-top)*.27f,p);
        // shelf and toys
        p.setColor(Color.rgb(142,92,55));c.drawRoundRect(l+(r-l)*.67f,top+(b-top)*.18f,l+(r-l)*.92f,top+(b-top)*.22f,8,8,p);
        p.setColor(Color.rgb(239,112,106));c.drawCircle(l+(r-l)*.73f,top+(b-top)*.15f,(r-l)*.025f,p);p.setColor(Color.rgb(102,170,229));c.drawCircle(l+(r-l)*.82f,top+(b-top)*.15f,(r-l)*.025f,p);
        // rug
        p.setColor(Color.rgb(151,119,205));c.drawOval(l+(r-l)*.28f,top+(b-top)*.65f,l+(r-l)*.73f,top+(b-top)*.88f,p);
        p.setColor(Color.rgb(194,170,232));c.drawOval(l+(r-l)*.36f,top+(b-top)*.69f,l+(r-l)*.65f,top+(b-top)*.84f,p);
        // bowl
        p.setColor(Color.rgb(83,148,201));c.drawArc(l+(r-l)*.68f,top+(b-top)*.72f,l+(r-l)*.86f,top+(b-top)*.86f,0,180,true,p);
        // small bed
        p.setColor(Color.rgb(232,143,153));c.drawRoundRect(l+(r-l)*.07f,top+(b-top)*.70f,l+(r-l)*.27f,top+(b-top)*.86f,14,14,p);p.setColor(Color.rgb(255,218,224));c.drawRoundRect(l+(r-l)*.09f,top+(b-top)*.72f,l+(r-l)*.17f,top+(b-top)*.78f,8,8,p);
    }
    private void drawHouseScreen(Canvas c,float w,float h){
        drawRef(c,refHouse,w,h);
        text(c,"Nível "+s.houseLevel+"   •   Bem-estar "+s.houseWellbeing()+"%",w*.50f,h*.585f,13,0xff55331d);
        if(!reaction.isEmpty()) text(c,reaction,w*.50f,h*.755f,12,0xff57331f);
    }
    private void drawAlbumScreen(Canvas c,float w,float h){
        drawRef(c,refAlbum,w,h);
        text(c,"Descobertos "+s.collectionCount()+" / 32",w*.50f,h*.275f,14,0xff5a331d);
        if(!reaction.isEmpty()) text(c,reaction,w*.50f,h*.885f,11,0xff5a331d);
    }
    private void drawAchievementsScreen(Canvas c,float w,float h){
        drawRef(c,refAchievements,w,h);
        text(c,s.achievementCount()+" / "+AchievementCatalog.count()+" desbloqueadas",w*.50f,h*.305f,14,0xff5a331d);
    }
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        float w=getWidth(),h=getHeight();
        c.drawColor(Color.rgb(234,248,255));
        if(screen==0){
            drawRef(c,isLandscape(w,h)?refHomeLandscape:refHomePortrait,w,h);
            text(c,"TCC • v6.7.0",w*.92f,h*.985f,8,0x99ffffff);
        }else if(screen==1){
            drawMapScreen(c,w,h);
        }else if(screen==2){
            drawRef(c,refGameplay,w,h);
            drawTccGameplayOverlay(c,w,h);
        }else if(screen==3){
            drawAlbumScreen(c,w,h);
        }else if(screen==4){
            drawHouseScreen(c,w,h);
        }else if(screen==5){
            drawRef(c,refSettings,w,h);
            if(!reaction.isEmpty()) text(c,reaction,w*.50f,h*.84f,11,0xff52301e);
        }else if(screen==7){
            drawAchievementsScreen(c,w,h);
        }else if(screen==8){
            drawRef(c,refHatch,w,h);
            int id=s.lastHatchedMonster;
            text(c,MonsterCatalog.name(id)+" • "+MonsterCatalog.rarity(id),w*.50f,h*.735f,15,0xff5b321e);
        }else if(screen==11){
            if(isLandscape(w,h)) drawGuideLandscape(c,w,h); else drawGuidePortrait(c,w,h);
        }else if(screen==10){
            drawHomeScene(c,w,h);drawHomeHud(c,w,h);
            text(c,"LOJINHA DOS MONSTRINHOS",w/2,h*.23f,31,Color.rgb(120,75,160));
            text(c,"Prévia segura • compras reais desativadas",w/2,h*.285f,17,Color.DKGRAY);
            button(c,"PACOTE 100 MOEDAS • DEMO",w*.12f,h*.36f,w*.88f,h*.45f,Color.rgb(95,175,235));
            button(c,"PACOTE 3 OVOS • DEMO",w*.12f,h*.49f,w*.88f,h*.58f,Color.rgb(245,170,75));
            button(c,"REMOVER ANÚNCIOS • DEMO",w*.12f,h*.62f,w*.88f,h*.71f,Color.rgb(130,105,210));
            button(c,"VOLTAR",w*.25f,h*.86f,w*.75f,h*.94f,Color.rgb(80,190,145));
        }else if(screen==9){
            drawHomeScene(c,w,h);drawHomeHud(c,w,h);
            text(c,"ENCONTRO DE CHEFE",w/2,h*.22f,34,Color.rgb(120,75,160));
            text(c,BossCatalog.name(selectedLevel),w/2,h*.31f,38,Color.DKGRAY);
            MonsterVisuals.draw(c,p,w/2,h*.48f,Math.min(w,h)*.12f,BossCatalog.indexForStage(selectedLevel)+24,true,s.colorBlindMode==1);
            text(c,BossCatalog.trait(selectedLevel),w/2,h*.64f,19,Color.DKGRAY);
            text(c,"Faça "+BossCatalog.target(selectedLevel)+" acertos",w/2,h*.70f,18,Color.DKGRAY);
            button(c,"COMEÇAR BATALHA",w*.12f,h*.76f,w*.88f,h*.85f,Color.rgb(165,85,190));
            button(c,"VOLTAR ÀS FASES",w*.20f,h*.88f,w*.80f,h*.95f,Color.rgb(95,175,235));
        }else if(screen==12){
            drawHomeScene(c,w,h);drawHomeHud(c,w,h);
            drawPill(c,w*.20f,h*.15f,w*.80f,h*.205f,Color.argb(235,255,241,216),Color.rgb(170,121,70));
            text(c,"🥚 BERÇÁRIO DE OVOS",w/2,h*.188f,22,Color.rgb(111,72,40));
            if(!s.incubatorBusy()){
                text(c,"Escolha um ovo • você tem "+s.eggs,w/2,h*.245f,16,Color.rgb(79,88,97));
                float[] xs={.22f,.50f,.78f};
                int[] shell={Color.rgb(183,224,255),Color.rgb(255,195,111),Color.rgb(187,230,157)};
                int[] accent={Color.rgb(77,150,218),Color.rgb(232,92,59),Color.rgb(68,151,79)};
                String[] names={"ÁGUA • 2 MIN","SOL • 4 MIN","FOLHA • 6 MIN"};
                for(int i=0;i<3;i++){
                    float l=w*(xs[i]-.12f),r=w*(xs[i]+.12f);
                    drawSoftPanel(c,l,h*.31f,r,h*.57f,Color.argb(230,255,255,255),Color.rgb(190,176,151));
                    drawEgg(c,w*xs[i],h*.405f,w*.055f,h*.070f,shell[i],accent[i]);
                    text(c,names[i],w*xs[i],h*.525f,11,Color.rgb(82,76,66));
                }
            }else{
                drawSoftPanel(c,w*.18f,h*.28f,w*.82f,h*.63f,Color.argb(232,255,255,255),Color.rgb(190,176,151));
                drawEgg(c,w*.50f,h*.43f,w*.09f,h*.12f,Color.rgb(245,220,180),Color.rgb(150,110,190));
                text(c,s.incubatorEggName(),w/2,h*.57f,21,Color.rgb(84,72,64));
                text(c,s.incubatorReady()?"Pronto para nascer!":"Tempo: "+s.incubatorClock(),w/2,h*.675f,19,Color.rgb(67,79,91));
                if(s.incubatorReady()) drawMenuButton(c,"✨","ABRIR OVO",w*.16f,h*.72f,w*.84f,h*.80f,Color.argb(228,78,182,142),Color.rgb(53,131,103));
                else drawMenuButton(c,"⚡","ACELERAR",w*.16f,h*.72f,w*.84f,h*.80f,Color.argb(228,237,174,84),Color.rgb(171,119,54));
                postInvalidateDelayed(1000);
            }
            drawMenuButton(c,"🏠","VOLTAR",w*.25f,h*.89f,w*.75f,h*.96f,Color.argb(228,74,160,229),Color.rgb(52,112,180));
        }else{
            drawHomeScene(c,w,h);
            text(c,"DESAFIO RÁPIDO",w/2,h*.21f,32,Color.DKGRAY);
            text(c,"Acerte 10 monstrinhos. Errou 3 vezes, termina!",w/2,h*.27f,18,Color.DKGRAY);
            MonsterVisuals.draw(c,p,w*targetX,h*targetY,Math.min(w,h)*.085f,s.favoriteMonster,true,s.colorBlindMode==1);
            text(c,"Pontos: "+challengeScore+"  •  Recorde: "+s.challengeBest,w/2,h*.78f,25,Color.DKGRAY);
            button(c,"SAIR",w*.30f,h*.84f,w*.70f,h*.93f,Color.rgb(130,105,210));
        }
    }
    private void startCurrentStage(){
        selectedLevel=s.safeStage(Math.max(1,s.level));
        taps=0;misses=0;moveTccTarget();
        if(s.isBoss(selectedLevel)){screen=9;reaction="";}
        else{s.beginLevel(getContext());screen=2;reaction="";}
    }
    @Override public boolean performClick(){
        super.performClick();
        sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_CLICKED);
        return true;
    }
    private void announce(String message){
        if(s.accessibilityAnnouncements==1 && message!=null && !message.isEmpty()) announceForAccessibility(message);
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()!=MotionEvent.ACTION_UP) return true;
        performClick();
        float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();
        if(screen==0){
            boolean land=isLandscape(w,h);
            if(!land){
                if(x>w*.84f&&y<h*.13f){screen=5;reaction="";}
                else if(y>h*.47f&&y<h*.61f&&x>w*.18f&&x<w*.82f){startCurrentStage();}
                else if(y>h*.61f&&y<h*.71f){
                    if(x<w*.34f){reaction=s.claimDaily(getContext())?"Presente recebido!":"Presente de hoje já coletado.";}
                    else if(x<w*.66f){screen=12;reaction="";}
                    else{screen=10;reaction="";}
                }else if(y>h*.71f&&y<h*.82f){
                    if(x<w*.34f)screen=3; else if(x<w*.66f)screen=4; else screen=5;
                }else if(y>h*.82f&&y<h*.91f){screen=7;reaction="";}
                else if(y>h*.91f){screen=6;challengeScore=0;misses=0;targetX=.5f;targetY=.5f;reaction="";}
            }else{
                if(x>w*.86f&&y<h*.15f){screen=5;reaction="";}
                else if(y>h*.67f&&x>w*.35f&&x<w*.68f){startCurrentStage();}
                else if(y>h*.70f&&x<w*.27f){screen=1;reaction="";}
                else if(y>h*.70f&&x>w*.73f){screen=3;reaction="";}
            }
        }else if(screen==1){
            if(y>h*.87f&&x<w*.34f){screen=0;reaction="";}
            else if(y>h*.84f&&x>w*.60f){startCurrentStage();}
            else{reaction="Fase atual: "+s.level+". Toque em JOGAR FASE.";}
        }else if(screen==2){
            if(y>h*.89f&&x>w*.30f&&x<w*.70f){screen=1;reaction="";}
            else{
                float dx=x-w*targetX,dy=y-h*targetY,hit=Math.min(w,h)*.105f;
                if(dx*dx+dy*dy<hit*hit){
                    taps++;moveTccTarget();
                    int need=s.isBoss(selectedLevel)?BossCatalog.target(selectedLevel):8;
                    if(taps>=need){
                        int earned=misses==0?3:(misses==1?2:1);
                        s.finishLevel(getContext(),selectedLevel,earned);
                        reaction="Fase concluída! "+s.reactionForProgress();
                        screen=0;
                    }
                }else{
                    misses++;
                    if(misses>=3){s.failLevel(getContext(),selectedLevel);reaction="Quase! Tente novamente.";screen=0;}
                }
            }
        }else if(screen==3){
            if(y>h*.89f&&x<w*.34f){screen=0;reaction="";}
            else if(y>h*.89f&&x<w*.68f){reaction="Toque em um monstrinho descoberto para defini-lo como favorito.";}
            else if(y>h*.89f){screen=7;reaction="";}
        }else if(screen==4){
            if(y>h*.88f&&x<w*.38f){screen=0;reaction="";}
            else if(y>h*.60f&&y<h*.73f){
                if(x<w*.34f) reaction=s.careAtHouse(getContext())?"Carinho dado!":"Limite de carinho de hoje.";
                else if(x<w*.67f) reaction=s.upgradeHouse(getContext())?"Casinha evoluiu!":s.houseUpgradeHint();
                else{int next=(s.houseDecor+1)%4;reaction=s.selectOrBuyDecor(getContext(),next)?"Decoração atualizada!":"Tema ainda bloqueado.";}
            }else if(y>h*.73f&&y<h*.86f){int next=(s.houseDecor+1)%4;reaction=s.selectOrBuyDecor(getContext(),next)?"Tema de decoração trocado!":"Tema ainda bloqueado.";}
        }else if(screen==5){
            if(x<w*.22f&&y<h*.13f){screen=0;reaction="";}
            else if(y>h*.26f&&y<h*.35f){s.toggleSound(getContext());reaction="Som "+(s.soundOn==1?"ligado.":"desligado.");}
            else if(y>h*.35f&&y<h*.44f){s.toggleSound(getContext());reaction="Música "+(s.soundOn==1?"ligada.":"desligada.");}
            else if(y>h*.44f&&y<h*.53f){s.toggleVibration(getContext());reaction="Vibração "+(s.vibrationOn==1?"ligada.":"desligada.");}
            else if(y>h*.53f&&y<h*.63f){s.toggleAccessibilityAnnouncements(getContext());reaction="Acessibilidade atualizada.";}
            else if(y>h*.63f&&y<h*.72f){reaction="Idioma: Português.";}
            else if(y>h*.72f&&y<h*.82f){reaction="Monstrinhos • Projeto TCC • Caeless Studios.";}
        }else if(screen==7){
            if(y>h*.88f&&x<w*.40f){screen=0;reaction="";}
        }else if(screen==8){
            if(y>h*.80f&&x<w*.50f){albumPage=s.lastHatchedMonster>=16?1:0;screen=3;reaction="";}
            else if(y>h*.80f){screen=0;reaction="";}
        }else if(screen==9){
            if(y>h*.75f&&y<h*.86f){taps=0;misses=0;moveTccTarget();s.beginLevel(getContext());screen=2;reaction="";}
            else if(y>h*.87f){screen=1;reaction="";}
        }else if(screen==10){
            if(y>h*.84f){screen=0;reaction="";}
            else reaction="Item demonstrativo. Compras reais continuam desativadas.";
        }else if(screen==11){
            if(y>h*.80f){s.markTutorialSeen(getContext());screen=0;reaction="Guia concluído!";}
        }else if(screen==12){
            if(y>h*.89f){screen=0;reaction="";}
            else if(!s.incubatorBusy()){
                int type=(y>h*.31f&&y<h*.57f)?(x<w*.36f?1:(x<w*.64f?2:3)):0;
                if(type>0) reaction=s.startIncubation(getContext(),type)?"Ovo colocado no berçário!":(s.eggs<=0?"Você ainda não tem ovos.":"Seu álbum já está completo.");
            }else if(y>h*.71f&&y<h*.82f){
                if(s.incubatorReady()){
                    if(s.claimIncubation(getContext())){screen=8;reaction="Novo amigo: "+MonsterCatalog.name(s.lastHatchedMonster)+"!";}
                }else reaction=s.speedIncubation(getContext())?"Incubação acelerada!":"Você precisa de "+s.incubatorSpeedCost()+" moedas.";
            }
        }else{
            if(y>h*.82f){screen=0;}
            else{float dx=x-w*targetX,dy=y-h*targetY;if(dx*dx+dy*dy<14000){challengeScore++;targetX=.18f+rng.nextFloat()*.64f;targetY=.32f+rng.nextFloat()*.35f;if(challengeScore>=10){s.finishChallenge(getContext(),challengeScore);reaction="Desafio completo!";screen=0;}}else{misses++;if(misses>=3){s.finishChallenge(getContext(),challengeScore);reaction="Desafio terminou.";screen=0;}}}
        }
        if(!reaction.isEmpty()) announce(reaction);
        invalidate();
        return true;
    }
}
