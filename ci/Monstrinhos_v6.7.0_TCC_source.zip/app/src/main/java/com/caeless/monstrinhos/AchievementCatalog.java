package com.caeless.monstrinhos;

/** Stable labels for persisted achievement bits. Never reorder existing ids. */
final class AchievementCatalog {
    private static final String[] TITLES={
        "10 estrelas","Fase 5","5 monstrinhos","Casinha nível 3",
        "Sequência 5","Primeira missão","5 ovos abertos","3 chefes vencidos",
        "20 partidas","3 chefes perfeitos","Carinho evolutivo","7 dias seguidos",
        "Desafio 10","Álbum completo","4 raros","Baú de chefe III",
        "20 reações","4 temas","10 perfeitas","Lenda dos Monstrinhos"
    };
    static String title(int id){ return id>=0&&id<TITLES.length?TITLES[id]:"Conquista"; }
    static int count(){ return TITLES.length; }
    private AchievementCatalog(){}
}
