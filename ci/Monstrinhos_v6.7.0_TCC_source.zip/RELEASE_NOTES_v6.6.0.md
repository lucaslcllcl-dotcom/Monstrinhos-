# Monstrinhos v6.6.0

- Personagens procedurais redesenhados com sombras, braços, barriga, orelhas internas, bochechas, pés e expressões mais amigáveis.
- Mapa de fases trocado de grade simples por caminho de aventura com nós circulares e chefes destacados.
- Casinha ganhou interior ilustrado com janela, tapete, brinquedos, cama e tigela, além de layout próprio em landscape.
- Álbum recebeu cards mais polidos e destaque visual para o favorito.
- Conquistas receberam cards compactos e leitura melhor.
- Mantidos package `com.caeless.monstrinhos`, save `monstrinhos_save_v1` e monetização real desativada.
