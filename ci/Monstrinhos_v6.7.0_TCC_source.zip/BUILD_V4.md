# Monstrinhos 4.0 — build-ready

Estado: fonte preparada para compilação Android real.

Pré-build:
`python3 tools/verify_release.py`

Build esperado em ambiente com Android SDK + Gradle:
`gradle :app:assembleDebug`

Antes de distribuir o APK:
1. confirmar package `com.caeless.monstrinhos`;
2. confirmar versionCode 4000;
3. usar e preservar uma única chave de assinatura da nova base;
4. executar `zipalign` e `apksigner verify`;
5. calcular SHA-256 do APK;
6. instalar/testar em Android moderno, incluindo rotação, save, TalkBack e retomada do app.

A antiga chave da v0.7.0 não faz parte desta reconstrução. A primeira chave real da nova base deverá ser preservada para todas as atualizações futuras.
