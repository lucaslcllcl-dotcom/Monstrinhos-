# Monstrinhos v3.3.0 RC1

Release Candidate de estabilidade.
- Validação defensiva central de moedas, ovos, XP, nível, sequências, fichas, amizade, casinha, pity, favorito e estrelas.
- Fases normalizadas para o intervalo 1–30.
- Estado persistente antigo continua compatível; nenhuma chave histórica foi removida.
- Package ID `com.caeless.monstrinhos` preservado.
- Save namespace `monstrinhos_save_v1` preservado.
- Launcher/manifest mantidos compatíveis com Android moderno.
- AdMob e Billing continuam ausentes; monetização real permanece desativada.
- Esta etapa prepara a base para build/assinatura/testes da v4.0.
