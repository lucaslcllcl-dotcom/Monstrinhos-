# Monstrinhos v5.4.0

- Berçário ganhou afinidades reais: Azul favorece amigos da água, Solar favorece amigos solares e Folha favorece amigos da floresta.
- Afinidade atua apenas em monstrinhos ainda não descobertos e nunca quebra a garantia de raridade.
- Custo de aceleração agora acompanha o tempo do ovo: 10 / 15 / 20 moedas.
- Save migrado de forma aditiva para schema 4, mantendo `monstrinhos_save_v1` e todos os IDs da coleção.
- Monetização real continua ausente.
