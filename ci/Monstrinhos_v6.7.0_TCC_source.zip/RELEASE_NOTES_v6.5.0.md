# Monstrinhos v6.5.0

- Home redesenhada com layout portrait refinado e botões menos pesados.
- Home landscape com distribuição própria, sem reaproveitar o portrait esticado.
- Tela Guia/Tutorial redesenhada com cards ilustrados e CTA mais claro.
- Ajustes de navegação/touch para as novas áreas do menu principal.
- Versionamento preparado para a próxima compilação real do APK.
