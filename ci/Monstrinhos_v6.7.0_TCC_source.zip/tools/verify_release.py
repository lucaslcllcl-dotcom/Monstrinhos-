#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
text="\n".join(p.read_text(errors="ignore") for p in root.rglob("*") if p.is_file() and p.suffix in {".java",".gradle",".xml",".yml"})
checks={
"package":"com.caeless.monstrinhos" in text,
"api36":"compileSdk 36" in text and "targetSdk 36" in text,
"version":"versionCode 6700" in text and "6.7.0" in text,
"backup_disabled":'android:allowBackup="false"' in text,
"save":"monstrinhos_save_v1" in text,
"save_schema7":"saveSchema=Math.max(7,saveSchema)" in text,
"procedural_ui":"drawHomeScene" in text and "drawGameplayScene" in text and "drawMenuButton" in text,
"tcc_reference_assets":"BitmapFactory" in text and "ref_home_portrait" in text and "ref_map" in text and "ref_gameplay" in text,
"procedural_monsters":"MonsterVisuals.draw" in text and "Soft floor shadow" in text and "Rosy cheeks" in text,
"monster_catalog":"MonsterCatalog" in text and '"Pingo"' in text,
"egg_nursery":"BERÇÁRIO DE OVOS" in text and "claimIncubation" in text,
"house":"refHouse" in text and "careAtHouse" in text and "upgradeHouse" in text and "selectOrBuyDecor" in text,
"album":"ÁLBUM" in text and "setFavorite" in text,
"achievements":"CONQUISTAS" in text and "AchievementCatalog" in text,
"settings":"refSettings" in text and "toggleAccessibilityAnnouncements" in text and "toggleSound" in text,
"boss":"BossCatalog" in text and "ENCONTRO DE CHEFE" in text,
"rotation_restore":"ui_screen" in text and ',0,12)' in text,
"accessibility":"AccessibilityEvent" in text and "setContentDescription" in text,
"no_admob":"com.google.android.gms.ads" not in text,
"no_billing":"com.android.billingclient" not in text,
"workflow":"gradle :app:assembleDebug" in text and "platforms;android-36" in text,
}
for k,v in checks.items(): print(("OK " if v else "FAIL ")+k)
sys.exit(0 if all(checks.values()) else 1)
