# Monstrinhos v6.4.0

- Gameplay redesenhado com cenário nativo, HUD, barra de acertos, corações e botão de saída.
- Álbum redesenhado com cards individuais, nomes e favorito.
- Berçário de ovos redesenhado com ovos procedurais e cards de seleção.
- Conquistas e Ajustes/Missões padronizados com a mesma identidade visual da Home.
- Casinha refinada e integrada ao mesmo padrão visual.
- Removida dependência das imagens de tela estática no renderer principal; a interface agora é composta por elementos nativos/procedurais do app.
- Base de CI preparada para build Android debug real.
- Monetização real continua desativada até aprovação do APK de jogo.
