# Monstrinhos v6.4.1 TESTE

- Build de identificação visual para evitar confusão com APKs antigos.
- Nome do app: Monstrinhos 6.4.1 TESTE.
- Marcador visível v6.4.1 TESTE na Home.
- Mantém a Home/Fases/Casinha/Gameplay/Álbum/Ovos/Ajustes da linha 6.4.x.
- Package preservado: com.caeless.monstrinhos.
