# Monstrinhos 6.0.0 — Test Candidate

- Consolida a linha rebuild como base oficial de testes.
- Android API 36 / target 36, package `com.caeless.monstrinhos`.
- Save `monstrinhos_save_v1` preservado; schema 7 aditivo.
- Assistência anti-frustração infantil após tentativas repetidas, sem alterar recompensas.
- Backup Android desativado para reduzir restaurações inconsistentes de saves entre instalações.
- AdMob e Google Play Billing continuam ausentes/desativados nesta base.
