# Monstrinhos v4.5.0

## Correções de compilação e integridade do progresso
- Corrige referências Java inválidas herdadas em `GameState` (`stars.length`, `stars[i]` e `winStreak`).
- A progressão de fases agora deriva do save textual `level_stars` por `starsFor()`, preservando o schema `monstrinhos_save_v1`.
- Sanitização de save normaliza estrelas por fase para 0..3 sem trocar chaves persistidas.
- Corrige o intervalo do monstrinho favorito para IDs estáveis 0..31.
- Mantém `bossChestLevel` compatível com saves antigos iniciados em zero.
- Package ID preservado: `com.caeless.monstrinhos`.
- Anúncios e compras reais permanecem ausentes/desativados.
