# Monstrinhos v5.9.0

- Reações do companheiro agora usam o monstrinho favorito e respondem ao estado real de fome, diversão e humor.
- Interagir por reação concede pequeno ganho de humor, mantendo progressão de amizade já existente.
- Nova indicação lógica `friendshipNext()` para progresso até o próximo nível de amizade.
- Mantidos package `com.caeless.monstrinhos`, save `monstrinhos_save_v1` e monetização real desativada.
- versionCode 5900 / versionName 5.9.0.
