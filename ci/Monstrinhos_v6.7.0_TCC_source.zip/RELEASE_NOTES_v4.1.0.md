# Monstrinhos 4.1.0

- Tela real de Conquistas integrada ao Álbum.
- 16 conquistas persistentes exibidas com estado bloqueado/desbloqueado.
- Catálogo estável de nomes desacoplado da renderização.
- Package ID e save `monstrinhos_save_v1` preservados.
- Anúncios e compras reais continuam ausentes/desativados.
