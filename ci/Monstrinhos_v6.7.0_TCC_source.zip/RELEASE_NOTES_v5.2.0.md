# Monstrinhos 5.2.0

- Preserva package `com.caeless.monstrinhos` e save `monstrinhos_save_v1`.
- Novo Guia dos Monstrinhos acessível pela Home, com regras de fases, estrelas, ovos, álbum, chefes e casinha.
- O guia registra conclusão no save sem invalidar progresso anterior.
- Área de acerto agora escala com a tela e oferece assistência discreta após dificuldade recorrente, melhorando uso infantil e acessibilidade.
- Chefes passam a usar a meta definida no `BossCatalog` também na lógica de conclusão, eliminando divergência entre UI e gameplay.
- Monetização real continua desativada; lojinha segue apenas demonstrativa.
