# Monstrinhos v6.3.0

- Tela de fases refeita com visual mais infantil, cards melhores e navegação por mundos mais clara.
- Tela da casinha refeita com painel visual melhor, status do monstrinho e ações em cards.
- Base preparada para compilação real com workflow Android Debug Build incluído no projeto.
- Mantidos package `com.caeless.monstrinhos`, save `monstrinhos_save_v1` e monetização real desativada.
