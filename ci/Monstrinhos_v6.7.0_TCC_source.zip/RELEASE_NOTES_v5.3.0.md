# Monstrinhos v5.3.0

- Novo Berçário de Ovos com três estilos e tempos de incubação.
- Incubação persistente no save schema 3 e resistente a reinício/rotação.
- Abertura do ovo só ocorre quando pronto; aceleração usa apenas moedas conquistadas no jogo.
- Anúncios e compras reais permanecem ausentes/desativados.
- Package `com.caeless.monstrinhos` e SharedPreferences `monstrinhos_save_v1` preservados.
