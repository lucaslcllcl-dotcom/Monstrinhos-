# Monstrinhos 5.5.0

- Casinha evolutiva agora limita a 5 carinhos recompensados por dia.
- Corrigida exploração de economia que permitia gerar moedas infinitas tocando repetidamente em carinho.
- O limite diário e o dia de referência são persistidos no save existente `monstrinhos_save_v1`.
- Carinhos extras continuam recebendo resposta amigável, sem gerar moedas/progresso.
- UI da Casinha mostra quantos carinhos recompensados restam no dia.
- Anúncios e compras reais permanecem desativados.
