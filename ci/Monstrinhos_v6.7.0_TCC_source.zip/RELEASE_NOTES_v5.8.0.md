# Monstrinhos v5.8.0

- Corrige erro de sintaxe no reset diário da Casinha que poderia bloquear a compilação.
- Necessidades agora decaem gradualmente entre dias (humor, fome e diversão), com limite seguro de 7 dias e pisos mínimos para evitar punição excessiva.
- Persistência aditiva `needs_day`; save migra para schema 6 mantendo `monstrinhos_save_v1`.
- Evolução manual da Casinha agora exige pelo menos 60% de bem-estar além das moedas, conectando cuidado e progressão.
- Carinho passa pela mesma rotina de evolução por cuidado usada por Alimentar/Brincar.
- Monetização real continua desativada.
