# Monstrinhos v5.7.0

- Casinha Evolutiva agora possui bem-estar persistente: humor, fome e diversão (0–100).
- Carinho melhora humor; Alimentar melhora fome; Brincar melhora diversão e humor.
- A Casinha mostra estado emocional e uma dica contextual da necessidade mais baixa.
- Mantidos package `com.caeless.monstrinhos`, save `monstrinhos_save_v1` e compatibilidade aditiva.
- Monetização real permanece desativada.
