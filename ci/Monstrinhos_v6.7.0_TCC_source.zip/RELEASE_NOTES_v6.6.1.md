# Monstrinhos v6.6.1

- Modo imersivo ativado para esconder as barras de navegação do Android durante o jogo.
- Botões inferiores reposicionados para não ficarem atrás da barra do sistema caso ela reapareça.
- Logo principal aumentada e subtítulo mais legível.
- Casinha: textos de status ampliados e controles reposicionados.
- Mapa: botão Voltar elevado para uma área segura.
