# Monstrinhos v4.6.0

- Adiciona identidade própria aos seis chefes, com nomes e descrições estáveis.
- Nova tela de encontro antes das fases 5, 10, 15, 20, 25 e 30.
- O contador de tentativa só começa quando a batalha é iniciada, evitando penalizar quem volta na apresentação.
- A sessão agora restaura corretamente também a nova tela de chefe após rotação/recriação da Activity.
- Mantidos package ID, save v1 e monetização real desativada.
