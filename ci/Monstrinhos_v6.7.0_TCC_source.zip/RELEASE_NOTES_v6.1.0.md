# Monstrinhos v6.1.0
- Integra as referências visuais aprovadas ao pacote Android como assets reais.
- Home recebe a arte vertical aprovada como camada ambiental, mantendo botões/hitboxes dinâmicos e legíveis.
- Fases, gameplay, álbum, casinha e ovos recebem a composição visual aprovada como ambientação leve; controles continuam nativos e funcionais.
- Alto contraste desativa a arte de fundo para preservar acessibilidade.
- Package/save permanecem com.caeless.monstrinhos / monstrinhos_save_v1.
- Monetização real continua fora desta build de estabilização visual.
