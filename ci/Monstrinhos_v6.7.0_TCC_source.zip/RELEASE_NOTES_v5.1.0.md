# Monstrinhos 5.1.0

- Preserva `com.caeless.monstrinhos` e o save `monstrinhos_save_v1`.
- Adiciona uma prévia de lojinha infantil com interfaces de moedas, ovos e remoção de anúncios.
- Nenhum anúncio, SDK publicitário, cobrança, BillingClient ou compra real foi ativado.
- A tela é explicitamente marcada como DEMO e os toques apenas informam que a monetização está desativada.
- Estado de UI da nova tela é preservado em rotação/recriação.
- Mantém fases, estrelas, ovos, coleção, chefes, conquistas, reações, casinha e acessibilidade da base 4.6.0.
