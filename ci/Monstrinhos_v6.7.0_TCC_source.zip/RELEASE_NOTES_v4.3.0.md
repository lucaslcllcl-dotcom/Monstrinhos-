# Monstrinhos v4.3.0

- Added stable `MonsterCatalog` IDs/names for all 32 collectibles without changing `ownedMask` semantics.
- Added an egg-hatching reveal screen with monster name, rarity, description and direct Album navigation.
- Persisted `last_hatched_monster` additively inside the frozen `monstrinhos_save_v1` preferences.
- Fixed missing `AccessibilityEvent` import that could prevent Java compilation.
- Fixed UI session restore so Achievements (screen 7) and hatch reveal (screen 8) survive rotation/recreation.
- Ads and real purchases remain disabled and no billing/ads SDK is included.
