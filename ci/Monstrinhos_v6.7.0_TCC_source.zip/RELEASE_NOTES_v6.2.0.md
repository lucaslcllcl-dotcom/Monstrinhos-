# Monstrinhos v6.2.0

- Home totalmente redesenhada com cenário nativo, HUD superior, logo estilizada, casinha ilustrada e botões infantis em cards.
- Removidos os grandes blocos transparentes da tela inicial.
- Navegação principal reorganizada: Jogar, Presente, Ovo, Loja, Álbum, Casinha, Ajustes, Conquistas e Desafio Rápido.
- Mantidos package `com.caeless.monstrinhos`, save `monstrinhos_save_v1` e monetização real desativada.
