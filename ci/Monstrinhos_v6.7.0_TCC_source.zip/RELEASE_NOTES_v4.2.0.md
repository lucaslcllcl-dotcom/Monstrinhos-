# Monstrinhos 4.2.0

- Corrige o catálogo de conquistas para refletir todos os bits de progresso já persistidos.
- Expande a tela de 16 para 20 conquistas sem alterar IDs antigos nem o save `monstrinhos_save_v1`.
- Adiciona a meta-conquista “Lenda dos Monstrinhos” ao completar as 19 anteriores.
- Ajusta a grade para 20 itens sem sobrepor o botão de retorno.
- Mantém anúncios e compras reais desativados.
