# Monstrinhos v6.7.0 TCC

Build de apresentação do TCC com as artes realísticas aprovadas incorporadas como skin visual funcional.

- Home realística (portrait e landscape)
- Mapa de fases realístico
- Gameplay realístico com alvo interativo e progresso dinâmico
- Álbum, Casinha, Conquistas e Ajustes com as artes de referência
- Tela de novo monstrinho após eclosão
- Hotspots funcionais sobre os elementos visuais
- Package e save preservados
- Monetização real continua desativada nesta build de TCC
